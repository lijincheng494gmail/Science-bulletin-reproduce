#!/usr/bin/env bash
set -euo pipefail

# Quick sanity check on the real COFCO manifest Excel (Plants_All).
# Usage:
#   bash scripts/run_sanity.sh

source .venv/bin/activate

python -m riec.experiments.run_sanity \
  --excel "data/中粮_专业化公司数智化调研_Manifest汇总.xlsx" \
  --sheet "Plants_All" \
  | tee "experiments/results/sanity.txt"

python experiments/figures/plot_sanity.py \
  --in "experiments/results/sanity.txt" \
  --out "experiments/figures/sanity.png" || true

echo "[run_sanity] outputs:"
echo "  - experiments/results/sanity.txt"
echo "  - experiments/figures/sanity.png (best-effort)"
