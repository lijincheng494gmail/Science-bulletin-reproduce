# Runbook (How to reproduce the results)

This runbook is written for reviewers and readers who want to rerun the key experiments.

## 0. Prerequisites

- Linux / macOS recommended (Windows users: use WSL or Git Bash)
- Python 3.10+ (tested with Python 3.10)
- `bash` available

## 1. Install dependencies

From the repo root:

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
```

(Alternatively, `RUN_ALL.sh` will call the helper script that sets up a venv for you.)

## 2. Smoke test (fast)

```bash
bash RUN_SMOKE.sh
```

Expected: a small set of outputs appear in `results/` and the script exits without errors.

## 3. Full reproduction (end-to-end)

```bash
bash RUN_ALL.sh   # (runs benchmark; sanity audit requires proprietary inputs)
```

This runs:

1) measurement audit (`results/sanity_audit/`)  
2) benchmark under multiple regimes (`results/benchmark/`)  
3) optional SIRI anchor demo (`results/siri_anchor/`)

## 4. Where to find key outputs

- Benchmark summary table (CSV):  
  `results/benchmark/tables/Table2_benchmark_tail_summary.csv`

- Tail-risk figures (PNG/PDF):  
  `results/benchmark/figures/`

- SIRI16 anchor outputs:  
  `results/siri_anchor/`

If you only want to compare against example artifacts, see `assets/expected_outputs/`.

## 5. Re-running from a clean state

To fully rerun:

```bash
rm -rf results/
bash RUN_ALL.sh   # (runs benchmark; sanity audit requires proprietary inputs)
```

## 6. Troubleshooting

- **`python: command not found`**  
  Try `python3` instead of `python`.

- **Package import errors**  
  Make sure you are running from the repo root, and that the venv is active.

- **macOS permission issues**  
  You may need to make scripts executable:  
  `chmod +x RUN_ALL.sh RUN_SMOKE.sh`



> Note (public version): proprietary industrial manifests are not included. The scripts will still reproduce the benchmark suite using the calibrated synthetic world. If you want to run the measurement-audit sanity step, provide your own manifest and pass `EXCEL=...`.
