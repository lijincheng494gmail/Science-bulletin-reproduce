#!/usr/bin/env bash
set -euo pipefail

# ============================================================
# RIEC reproducibility runner (one-click)
#
# EN: Run sanity + multi-seed benchmark + figure suite (+ optional SIRI)
# 中文：一键跑通 sanity + 多 seed benchmark + 图表套件（+ 可选 SIRI）
# ============================================================

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# -----------------------------
# User-tunable parameters
# -----------------------------
SEEDS="${SEEDS:-50}"            # number of seeds for benchmark
PRESET="${PRESET:-quick}"       # benchmark preset
SHEET="${SHEET:-Plants_Core}"   # Excel sheet name inside manifest.xlsx
RUN_SIRI="${RUN_SIRI:-1}"       # 1=run SIRI demo if html exists; 0=skip

EXCEL="${EXCEL:-$ROOT_DIR/data/manifest.xlsx}"   # input manifest
SIRI_HTML="${SIRI_HTML:-$ROOT_DIR/data/siri/siri_assessment.html}"

# -----------------------------
# Paths
# -----------------------------
VENV_DIR="$ROOT_DIR/.venv"
PY="$VENV_DIR/bin/python"
PIP="$VENV_DIR/bin/pip"

CODE_DIR="$ROOT_DIR/code/riec_lab"

RESULTS_DIR="$ROOT_DIR/results"
SANITY_DIR="$RESULTS_DIR/sanity"
BENCH_DIR="$RESULTS_DIR/benchmark"
FIG_DIR="$RESULTS_DIR/figures/${PRESET}_${SEEDS}"
TABLE_DIR="$BENCH_DIR/summary_${PRESET}_${SEEDS}"

SEED_DIR="$BENCH_DIR/seeds_${PRESET}_${SEEDS}"
MERGED_CSV="$BENCH_DIR/benchmark_${PRESET}_all_${SEEDS}.csv"

echo "[RUN_ALL] ROOT_DIR: $ROOT_DIR"
echo "[RUN_ALL] SEEDS:    $SEEDS"
echo "[RUN_ALL] PRESET:   $PRESET"
echo "[RUN_ALL] SHEET:    $SHEET"
echo "[RUN_ALL] EXCEL:    $EXCEL"
echo "[RUN_ALL] RUN_SIRI: $RUN_SIRI"

mkdir -p "$RESULTS_DIR" "$SANITY_DIR" "$BENCH_DIR" "$FIG_DIR" "$TABLE_DIR" "$SEED_DIR"

# -----------------------------
# 1) Setup Python environment
# -----------------------------
if [ ! -x "$PY" ]; then
  echo "[RUN_ALL] Creating venv at: $VENV_DIR"
  if command -v python3 >/dev/null 2>&1; then
    python3 -m venv "$VENV_DIR"
  else
    python -m venv "$VENV_DIR"
  fi
fi

echo "[RUN_ALL] Python: $("$PY" -V)"

echo "[RUN_ALL] Upgrading pip ..."
"$PY" -m pip install -U pip

# Install dependencies
# Try lock first; fall back to loose requirements if needed.
echo "[RUN_ALL] Installing dependencies ..."
if "$PIP" install -r "$ROOT_DIR/requirements.lock.txt" >/dev/null 2>&1; then
  echo "[RUN_ALL] Installed from requirements.lock.txt (tested lock)."
else
  echo "[RUN_ALL] Lock install failed (maybe different Python/OS). Falling back to requirements.txt ..."
  "$PIP" install -r "$ROOT_DIR/requirements.txt"
fi

# Install local package
echo "[RUN_ALL] Installing local package (editable): $CODE_DIR"
"$PIP" install -e "$CODE_DIR" -q

# -----------------------------
# 2) Sanity run (measurement audit smoke test)
# -----------------------------
echo "[RUN_ALL] (1/4) Sanity ..."
echo "[RUN_ALL] Writing: $SANITY_DIR/sanity.txt"
"$PY" -m riec.experiments.run_sanity   --excel "$EXCEL"   --sheet "$SHEET"   --seed 7   | tee "$SANITY_DIR/sanity.txt" >/dev/null

# -----------------------------
# 3) Benchmark (multi-seed)
# -----------------------------
echo "[RUN_ALL] (2/4) Benchmark (multi-seed) ..."
for s in $(seq 1 "$SEEDS"); do
  out_csv="$SEED_DIR/benchmark_${PRESET}_seed${s}.csv"
  echo "  - seed=$s -> $out_csv"
  "$PY" -m riec.experiments.run_benchmark     --excel "$EXCEL"     --sheet "$SHEET"     --seed "$s"     --preset "$PRESET"     --out "$out_csv"     >/dev/null
done

# -----------------------------
# 4) Merge + analyze + figures
# -----------------------------
echo "[RUN_ALL] (3/4) Merge seeds ..."
"$PY" "$ROOT_DIR/scripts/python/merge_benchmark_seeds.py"   --in_dir "$SEED_DIR"   --glob "benchmark_${PRESET}_seed*.csv"   --out "$MERGED_CSV"   >/dev/null

echo "[RUN_ALL] (4/4) Figures + tables ..."
"$PY" "$ROOT_DIR/scripts/python/analyze_benchmark.py"   --in "$MERGED_CSV"   --fig_dir "$FIG_DIR"   --table_dir "$TABLE_DIR"   >/dev/null

# -----------------------------
# Optional: SIRI anchor demo
# -----------------------------
if [ "$RUN_SIRI" = "1" ] && [ -f "$SIRI_HTML" ]; then
  echo "[RUN_ALL] Optional SIRI anchor ..."
  OUT_SIRI="$RESULTS_DIR/siri_anchor"
  mkdir -p "$OUT_SIRI"
  "$PY" -m riec.experiments.run_siri_anchor     --html "$SIRI_HTML"     --out "$OUT_SIRI"     --plant "SIRI assessment"     --topk 8     >/dev/null
  echo "[RUN_ALL] SIRI outputs: $OUT_SIRI"
else
  echo "[RUN_ALL] SIRI skipped (RUN_SIRI=$RUN_SIRI, file exists? $( [ -f "$SIRI_HTML" ] && echo yes || echo no ))"
fi

echo
echo "[RUN_ALL] DONE."
echo "  - Sanity:   $SANITY_DIR/sanity.txt"
echo "  - Benchmark merged: $MERGED_CSV"
echo "  - Figures:  $FIG_DIR"
echo "  - Tables:   $TABLE_DIR"
echo
