#!/usr/bin/env bash
# Quick smoke run (fast): sanity + 3-seed benchmark + figures
SEEDS=3 PRESET=quick bash RUN_ALL.sh
