# `code/riec_lab/data/` (optional legacy inputs)

This directory is **not required** for reproducing the paper results in this submission bundle.

In earlier internal versions of the project we sometimes kept:
- a merged survey report in **DOCX** format, and
- an intermediate Excel manifest used during extraction.

Those raw/merged inputs may contain sensitive organizational context, so they are **not included** here.
For reproducibility, reviewers should use the anonymized/minimal inputs shipped in:

- `RIEC_REPRO_SUBMISSION/data/manifest.xlsx`
- `RIEC_REPRO_SUBMISSION/data/siri/` (optional SIRI HTML)

The runner (`RUN_ALL.sh`) accepts explicit `EXCEL=...` and `SIRI_HTML=...` paths if you wish to test with your own inputs.
