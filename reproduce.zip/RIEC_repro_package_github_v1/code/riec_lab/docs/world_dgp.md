# COFCO-inspired 虚拟工厂世界：DGP / World Generator 说明

这份文档解释“为什么要做 world 生成器”和“生成器的 DGP 具体是什么”。

---

## 1. 为什么要做虚拟工厂世界（World）

你现在的现实约束是：

- 你手里有 8 万字集团级调研报告 + Excel 量化指标；
- 但你无法再回到中粮做第二轮实验或在线 A/B。

这意味着：如果想冲一个“方法论 + 可复现 benchmark”级别的论文，
你需要一个东西让外界 **可以重复验证你的 claim**：

> **RIEC 在强层级/强相关/小样本的工业系统中，比纯 CV / 纯 BIC 更稳健。**

只靠一次真实数据的结果很难让评审信服（尤其是 Nat 系），
因为他会说：

- 你是不是“这个数据集碰巧更适合你的方法”？
- 你的结论能否迁移到别的工业集团/别的指标体系？
- 你有没有系统比较 baselines？

所以 world 的意义是：

- **把 COFCO 的真实约束“抽象成可公开的 DGP”**
- 让任何人都能：生成数据 → 跑 RIEC / baseline → 复现你的图和结论

这就是 benchmark/platform 的贡献点。

---

## 2. world 生成器要实现的“功能需求”

一个合格的 world 生成器至少要满足：

1) **被现实约束（calibration）**  
   - 变量的边际分布/相关结构/组大小分布，来自你的 Excel manifest  
   - 例如：专业化公司数量、工厂规模分布、星级分布、成熟度分布

2) **可调控（regime control）**  
   - N（样本量）、ICC（组内相关强度）、噪声水平、misspecification 程度  
   - 这些是你做系统仿真图的“旋钮”

3) **可评测（ground truth）**  
   - 生成数据的同时，把“真实结构/真实收益函数”也输出  
   - 这样才能评估：结构恢复率、预测风险、决策 regret、稳定性

---

## 3. 本 repo 的 DGP：结构定义

在 `riec/world/dgp.py` 里，我们用一个足够通用的 DGP：

### 3.1 分组（集团层级）

- group = 专业化公司 / 业态 / 区域（你可以指定 `group_col`）
- 组大小 `n_g` 来自 Excel 的经验分布（抽样 + 缩放到目标 N）

### 3.2 特征 X：相关 + 分层 + latent types

我们把工厂特征向量写成：

\[
X_{i} = \mu_{z_i} + u_{g(i)} + \epsilon_i
\]

- \(z_i\)：latent factory type（用 KMeans 从真实 manifest 上估计若干类）
- \(\mu_{z}\)：每个 latent type 的均值向量
- \(u_g\)：组效应（导致 ICC）
- \(\epsilon_i\)：组内噪声（导致相关结构）

关键点：  
- 组内相关性由 \(u_g\) 控制，近似 ICC：
  \[
  ICC \approx \frac{\mathrm{Var}(u)}{\mathrm{Var}(u)+\mathrm{Var}(\epsilon)}
  \]
- 相关结构由 `cov_within`（组内协方差）决定

### 3.3 outcome y：可控 misspecification

我们生成一个合成的回归任务（用于 benchmark）：

\[
y = X\beta + \alpha\sin(X\gamma) + b_g + \eta
\]

- \(\beta\)：线性信号
- \(\alpha\sin(\cdot)\)：非线性 misspec component（alpha=misspec_level）
- \(b_g\)：y 的组效应（可选）
- \(\eta\)：噪声

这样你可以系统测试：

- 当真相是线性的：BIC 结构恢复应更强
- 当真相有 misspec：纯 BIC 容易选错结构/过拟合
- RIEC 是否能在两者之间更稳

---

## 4. Calibration：怎么把真实 Excel “编译”成 DGP 参数

`CofcoWorldGenerator.fit()` 做的事情：

1) 选定一些数值特征列 `feature_cols`（比如星级、成熟度、采集点位、自动采集率…）
2) 从真实数据估计：
   - overall mean
   - between covariance（组间差异）
   - within covariance（组内相关）
3) 用 KMeans 把工厂划分为 K 个 latent types，得到：
   - latent weights
   - latent means
4) 记录 group size 的经验分布（后面采样时使用）

这一步就是你说的 “DGP 编译器”：  
输入 = Excel manifest  
输出 = world 的参数包（WorldCalibration）

---

## 5. 你论文里怎么写 world 这部分

建议写成三段（不用太长）：

1) **Motivation**：真实数据难重复实验 → 需要一个现实约束的 benchmark  
2) **Design**：DGP 结构（X 的分层/相关/latent types；y 的可控 misspec）  
3) **Calibration & Regimes**：参数来自 COFCO manifest；支持调 N/ICC/噪声/ misspec

---

## 6. 对应到代码

- `CofcoWorldGenerator.fit(manifest_df, group_col, feature_cols)`  
  → 输出 `WorldCalibration`

- `CofcoWorldGenerator.sample(WorldConfig(...), calibration, outcome_spec=None)`  
  → 输出 `df`（含 group_col/latent_type/y）+ `truth`

你可以用 `riec/experiments/run_sanity.py` 和 `run_benchmark.py` 直接跑通流程。
