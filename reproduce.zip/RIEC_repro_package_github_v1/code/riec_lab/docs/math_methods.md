# RIEC 数学方法与评分函数（简明版）

这份文档是给“很久没碰过项目的人”用的：只看它，你就能把 RIEC 的核心数学完全捡起来。

---

## 1. RIEC 到底在干什么

RIEC（Robust, Interpretable, Explainable & Controllable）不是一个单独的模型，
而是一套 **“测量 → 建模 → 选模 → 决策/审计”** 的通用流程。

它要解决的是工业集团场景里很典型的一类数据问题：

- **强层级/强相关**：同一专业化公司/同一业态/同一地区的工厂互相很像（cluster correlation）。
- **小样本/脏数据**：深度调研样本不大，指标口径不齐、缺失多。
- **结构很多**：你可以选 i.i.d、层级模型、低秩结构、latent type 等。
- **决策需要可审计**：不只是预测好坏，还要给出“为什么这么选模型/不确定性多大/风险在哪”。

RIEC 的核心贡献点是：**把“测量阶段估到的 n_eff（有效样本量）和相关结构”，显式注入模型选择（BIC/预测泛化的折中）**。

---

## 2. Measurement：ICC → n_eff（有效样本量）

### 2.1 为什么要 n_eff

当数据来自 cluster sampling（按公司/区域/业态分组采样）时，
样本点之间不是独立的。

- 名义样本量是 `n`
- 但真正“提供独立信息”的量更少，我们记为 `n_eff`

用 `n_eff` 代替 `n` 去做信息准则惩罚项（`k log n`）是 RIEC 的关键。

### 2.2 ICC（组内相关）估计

对每个数值特征 `x`，用 one-way random effects 的 ANOVA 分解：

- `MSB`：组间均方
- `MSW`：组内均方
- `m̄`：平均组大小

ICC(1) 的常用估计：

\[
\mathrm{ICC}=\frac{\mathrm{MSB}-\mathrm{MSW}}{\mathrm{MSB}+(m̄-1)\mathrm{MSW}}
\]

经验上，ICC 越大，说明 “同组更像”，层级结构越强。

### 2.3 设计效应（design effect）与 n_eff

在组大小不均匀时，一个常用的 Kish-like 设计效应：

\[
\mathrm{deff} = 1 + \mathrm{ICC}\left(\frac{\sum_g n_g^2}{n}-1\right)
\]

于是

\[
n_{\mathrm{eff}}=\frac{n}{\mathrm{deff}}
\]

---

## 3. Modeling：候选模型 = (结构 C, 学习器 f)

RIEC 的“候选集合”不是只摆一堆模型，
而是你要把模型分为两层：

- **结构 C**：是否考虑 group、是否低秩、是否 latent type、是否图结构……
- **学习器 f**：在线性/岭/树/GBDT 等不同函数族里选。

**两阶段选模**的意义：先在固定结构 C 内选最合适的 f，再在不同结构 C 之间比。

---

## 4. Selection：BIC + 预测提升（XPE）的混合评分

### 4.1 Cross-validated MSE 与 baseline

对回归问题：

- 模型的 CV MSE：`MSE_cv(model)`
- baseline 预测器：训练集均值预测
- baseline 的 CV MSE：`MSE_cv(base)`

### 4.2 XPE（预测提升因子）

RIEC 用的不是“误差本身”，而是**相对提升**：

\[
\mathrm{XPE} = \frac{\mathrm{MSE}_{cv}(\text{base})}{\mathrm{MSE}_{cv}(\text{model})}
\]

- XPE > 1：模型比 baseline 好（提升）
- XPE < 1：模型还不如 baseline（退化）

这个定义有一个很重要的好处：
后面可以用 `log(1/XPE)`，好的模型会得到负项奖励。

### 4.3 Gaussian log-likelihood 与 BIC(n_eff)

在实现里我们用 Gaussian 回归的 plug-in 似然：

- RSS = \(\sum_i (y_i-\hat y_i)^2\)
- \(\hat\sigma^2=\mathrm{RSS}/n\)

\[
\log L = -\frac{n}{2}\left[\log(2\pi \hat\sigma^2) + 1\right]
\]

BIC 使用 **有效样本量 n_eff**：

\[
\mathrm{BIC} = -2\log L + k\log(n_{\mathrm{eff}})
\]

其中 `k` 是复杂度（线性模型通常是参数个数）。

### 4.4 C_λ：把“预测提升”混进信息准则

RIEC 的核心混合评分（越小越好）：

\[
C_{\lambda}=\mathrm{BIC} + \lambda(n_{\mathrm{eff}})\cdot\log\left(\frac{1}{\mathrm{XPE}}\right)
\]

并用一个“随样本量退火”的 λ：

\[
\lambda(n_{\mathrm{eff}})=\frac{c}{\log(n_{\mathrm{eff}})}
\]

- 当 `n_eff` 小：`log(n_eff)` 小 ⇒ λ 大 ⇒ 更依赖 CV 的泛化信号（防过拟合）。
- 当 `n_eff` 大：λ 变小 ⇒ 更接近纯 BIC（更偏结构正确/复杂度惩罚）。

---

## 5. Gatekeeper：在“乱七八糟候选”里先拦截

工业数据里经常会出现：

- 某些模型拟合失败 / 数值崩
- 或者 CV 不稳定导致“靠运气”

所以 RIEC 常见做法是先加一个 gatekeeper（门卫）：

- 例如 `R^2_full >= -0.05`（允许弱模型，但过滤明显坏的）
- 或者更严格的阈值/稳健统计规则

---

## 6. 输出与可审计性（你论文里要强调的）

RIEC 的“输出”不是一句“最优模型=xxx”，而是一整套审计材料：

- Measurement manifest（缺失率、ICC、n_eff、相关性）
- 每个候选模型的：CV MSE、XPE、loglik、BIC、C_λ
- Gatekeeper 过滤记录
- 最终结构选择 & 备选结构（以及为什么没选）

这套东西是你写论文时最能体现“可审计”的部分。

---

## 7. 对应到代码

本 repo 里核心落点：

- `riec/measurement.py`：ICC、n_eff、manifest、hints
- `riec/models/*`：候选模型（含 group FE 结构）
- `riec/selection.py`：XPE、BIC(n_eff)、C_λ、两阶段选择
- `riec/world/dgp.py`：COFCO-inspired 虚拟工厂世界（可调 N/ICC/噪声/misspec）
