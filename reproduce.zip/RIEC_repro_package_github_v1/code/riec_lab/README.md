# riec_lab (core package)

This directory contains the core Python implementation used by the reproducibility package:

- measurement audit (missingness / ICC / effective sample size),
- virtual-factory benchmark generator,
- model-selection rules (CV, BIC_eff, RIEC, Guarded-RIEC / RIEC-B),
- scripts to reproduce the figures and summary tables.

Note: Proprietary industrial inputs (original survey manifests / merged reports) are **not** included in the public version.
The benchmark results can be reproduced using the calibrated synthetic world provided by the codebase.
