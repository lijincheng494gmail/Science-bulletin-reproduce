# RIEC 实验工程包（可复现版）

这个压缩包把你目前“堆在一起”的东西整理成一个**可跑通的实验工程**：

- `riec/`：RIEC 本体（Measurement → n_eff → 选模/诊断），以及一个可控的虚拟工厂世界（DGP）
- `experiments/`：实验输出目录（结果 CSV / 图）
- `scripts/`：一键 Bash 脚本（建环境、跑 sanity、跑 benchmark、出图）
- `data/`：中粮调研量化 Excel + 报告 Docx（原始资料）
- `paper/`：论文草稿（Nat Comp Sci / Science Bulletin）+ “教科书级附录” LaTeX
- `legacy/`：历史文件与旧包归档（防丢）

> 你现在做实验阶段，最核心就是：**代码工程可复现 + world generator 可控 + 一键跑出图表**。  
> 真正的大规模实验，只要把 `run_benchmark` 的 regime/seed 扩起来即可。

---

## 目录结构（你打开 zip 看到的应该是这样）

```
RIEC_Experiment_Engineering_Pack/
  README.md
  requirements.txt
  pyproject.toml
  LICENSE
  .gitignore

  riec/                         # 你的 RIEC 本体（最重要）
    measurement.py              # MeasurementEngine: 清洗/ICC/n_eff/manifest/hints
    selection.py                # RIECSelector: CV + (AIC/BIC) + 混合准则
    models/
      base.py
      sklearn_models.py
    world/
      dgp.py                    # 虚拟工厂世界 DGP（可控：n/ICC/噪声/latent type）
    io/
      cofco_reports.py          # 报告解析/结构化（偏启发式）
    experiments/
      run_sanity.py             # 用真实 Excel 做一次“端到端” sanity
      run_benchmark.py          # 虚拟世界 benchmark（CV/BIC/RIEC 对比）
      extract_from_docx.py      # 从 docx 抽取信息的 demo（可按需改）

  experiments/
    results/                    # 运行后自动生成 benchmark.csv / sanity.txt
    figures/                    # 运行后自动生成 benchmark_summary.png
      plot_benchmark.py
      plot_sanity.py
    configs/                    #（预留）如果你后续想用 YAML 驱动实验

  scripts/
    setup_venv.sh
    run_sanity.sh
    run_benchmark.sh
    run_all.sh                  # 一键跑通（推荐先跑这个）

  data/
    manifest.xlsx
    数智化工厂调研报告汇总.docx
    README.md                   # 数据说明/口径

  paper/
    drafts/                     # 中英文 markdown 草稿
      NatCompSci_CN_draft.md
      ScienceBulletin_CN_draft.md
      RIEC_paper_drafts/...
    appendix_textbook/          # “教科书级附录” LaTeX
      RIEC_textbook_appendix/...

  tests/
    test_smoke.py               # 极简烟雾测试（保证核心模块能跑）

  legacy/
    riec_legacy.py              # 你最早的蓝本 riec.py
    original_packs/             # 之前生成过的 zip 归档
```

---

## 1) 最推荐的跑法：一键（bash）

在项目根目录（就是这个 README 同级目录）执行：

```bash
bash scripts/run_all.sh
```

它会做三件事：

1. 建立 `.venv` 并安装依赖  
2. 跑 `run_sanity`（读你的真实 Excel，跑一次 Measurement + RIEC 选模）  
3. 跑 `run_benchmark`（虚拟工厂世界，输出 benchmark.csv + 一张 summary 图）

跑完你应该看到：

- `experiments/results/sanity.txt`
- `experiments/results/benchmark.csv`
- `experiments/figures/benchmark_summary.png`

---

## 2) 不用一键，手动跑（更可控）

### 2.1 建环境

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -U pip
pip install -r requirements.txt
```

### 2.2 跑真实 manifest 的 sanity

```bash
python -m riec.experiments.run_sanity \
  --excel "data/manifest.xlsx" \
  --sheet "Plants_All"
```

### 2.3 跑虚拟工厂世界 benchmark 并保存 CSV

```bash
python -m riec.experiments.run_benchmark --out experiments/results/benchmark.csv
```

### 2.4 出图

```bash
python experiments/figures/plot_benchmark.py \
  --in experiments/results/benchmark.csv \
  --out experiments/figures/benchmark_summary.png \
  --metric cv_risk
```

---

## 3) 你问的“怎么检查每一处程序”：给你一个可执行的 checklist

### A. 结构检查（最先做）
```bash
python -m compileall riec
```
这能快速暴露语法错误/循环引用。

### B. 单元级烟雾测试（保证核心链条能跑）
```bash
python -m unittest discover -s tests -p "test_*.py" -q
```
它会跑 `tests/test_smoke.py`，覆盖：
- world DGP 生成数据
- MeasurementEngine 跑出 n_eff / hints
- RIECSelector 能选出一个模型

### C. 模块自检（逐个跑）
- 真实数据 sanity：`python -m riec.experiments.run_sanity ...`
- 虚拟世界 benchmark：`python -m riec.experiments.run_benchmark ...`
- 图脚本：`python experiments/figures/plot_benchmark.py ...`

### D. “是不是跑对了”的输出特征
- `sanity.txt` 里应该能看到：ICC、n_eff、候选模型的 BIC/CV/criterion 对比，以及最终被选中的模型
- `benchmark.csv` 有多行（regime × seed × method × candidate），不应该只有一两行
- summary 图能正常生成（如果图生成失败，通常是 matplotlib 或路径问题）

---

## 4) 实验阶段你下一步真正要扩的地方（不用现在就改，但你之后肯定会改）

- `riec/world/dgp.py`：把 “COFCO inspired world” 做得更像真实（8维成熟度、latent type、KPI 相关结构、ICC 可调）
- `riec/models/`：把候选模型族补齐（层级模型/低秩/图结构/latent class 之类）
- `riec/selection.py`：把两阶段搜索、λ(n_eff) 退火、稳定性诊断做更完整
- `riec/experiments/run_benchmark.py`：把 regime 网格变大，加入 ablation（错估 n_eff、假装 i.i.d.、只用 CV/BIC）

> 但这些都是**在“能一键跑通”之后**再扩。你现在最缺的是工程闭环，不是再写一堆概念。

---

## 5) 论文材料在哪里？

- 论文草稿：`paper/drafts/`
- 教科书级附录 LaTeX：`paper/appendix_textbook/`
- 原始资料：`data/`

---

如果你希望我下一步把 `run_benchmark` 做成“config 驱动 + 自动出论文图（4-6 张核心图）”的标准流水线，我可以直接在这个工程结构上继续补齐（不改你的主线，只加工具链）。  
