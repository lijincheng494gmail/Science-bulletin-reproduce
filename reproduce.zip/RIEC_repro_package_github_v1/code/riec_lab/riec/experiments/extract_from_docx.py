"""
Extract structured indicators from the aggregated COFCO survey report (docx).

Usage:
  python -m riec.experiments.extract_from_docx --docx 数智化工厂调研报告汇总.docx --out extracted.csv

This extracts the "技术水平评估" tables (自动化/网联化/智能化 star ratings)
and associates them with the nearest heading title.
"""
from __future__ import annotations

import argparse
import pandas as pd

from riec.io import parse_reports_docx


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--docx", type=str, required=True)
    ap.add_argument("--out", type=str, required=True)
    args = ap.parse_args()

    df = parse_reports_docx(args.docx)
    df.to_csv(args.out, index=False)
    print("Extracted rows:", len(df))
    print("Wrote:", args.out)


if __name__ == "__main__":
    main()
