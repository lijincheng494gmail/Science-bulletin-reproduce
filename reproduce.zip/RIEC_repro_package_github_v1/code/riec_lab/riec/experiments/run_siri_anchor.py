"""Run SIRI Anchor (Use A): standard diagnostic language layer.

This script turns a local SIRI assessment HTML file into:
  - a machine-readable SIRI16 profile table (current/avg/BIC/gap)
  - a deterministic 'impact' ranking (cost/kpi/gap weighted)
  - plots for inclusion in SB-style papers and management slides

Usage (recommended via bash wrapper):
  python -m riec.experiments.run_siri_anchor --html path/to/智能制造评估.html --out_dir 05_results/siri_anchor

Output files:
  out_dir/
    siri_profile.csv
    siri_topk.csv
    siri_meta.json
    siri_profile.png
    siri_impact.png
    siri_anchor_summary.md
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd
import matplotlib.pyplot as plt

from riec.siri import parse_siri_html
from riec.siri import siri_impact_table


def _plot_profile(df: pd.DataFrame, out_png: Path, title: str) -> None:
    # current vs avg vs bic
    x = list(range(len(df)))
    plt.figure(figsize=(12, 6))
    plt.plot(x, df["current"], marker="o", label="current")
    plt.plot(x, df["avg"], marker="o", label="avg")
    plt.plot(x, df["bic"], marker="o", label="bic")
    plt.xticks(x, df["dimension"], rotation=45, ha="right")
    plt.ylabel("maturity level")
    plt.title(title)
    plt.legend()
    plt.tight_layout()
    out_png.parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(out_png, dpi=200)
    plt.close()


def _plot_impact(df: pd.DataFrame, out_png: Path, title: str, topk: int = 10) -> None:
    df2 = df.sort_values("impact", ascending=False).head(topk)
    plt.figure(figsize=(10, 6))
    plt.barh(df2["dimension"], df2["impact"])
    plt.gca().invert_yaxis()
    plt.xlabel("impact (normalized, higher = more priority)")
    plt.title(title)
    plt.tight_layout()
    out_png.parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(out_png, dpi=200)
    plt.close()


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--html", required=True, help="Path to local SIRI assessment HTML (e.g., 智能制造评估.html)")
    ap.add_argument("--out_dir", required=True, help="Output directory (e.g., 05_results/siri_anchor)")
    ap.add_argument("--plant", default="(SIRI assessment)", help="Plant label for titles")
    ap.add_argument("--topk", type=int, default=8, help="Top-K dimensions to output")
    args = ap.parse_args()

    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    siri = parse_siri_html(args.html)
    df = siri_impact_table(siri)

    # Save tables
    profile_csv = out_dir / "siri_profile.csv"
    df.to_csv(profile_csv, index=False, encoding="utf-8-sig")

    topk_df = df.sort_values("impact", ascending=False).head(args.topk).reset_index(drop=True)
    topk_csv = out_dir / "siri_topk.csv"
    topk_df.to_csv(topk_csv, index=False, encoding="utf-8-sig")

    # Save metadata
    meta = {
        "plant": args.plant,
        "W": siri.get("W", {}),
        "n_cost_items": len(siri.get("cost_items", [])),
        "n_kpi_items": len(siri.get("kpi_items", [])),
    }
    meta_json = out_dir / "siri_meta.json"
    meta_json.write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")

    # Plots
    _plot_profile(df, out_dir / "siri_profile.png", title=f"SIRI16 profile: {args.plant}")
    _plot_impact(df, out_dir / "siri_impact.png", title=f"SIRI16 priority (impact): {args.plant}", topk=max(args.topk, 10))

    # Short markdown summary (SB-friendly, copy-paste)
    md = []
    md.append(f"# SIRI anchor summary: {args.plant}\n")
    md.append("## What this is\n")
    md.append("This is the 'Use A' layer: we express diagnosis using the standard SIRI 16-dimension vocabulary.\n")
    md.append("The impact ranking is deterministic (same input -> same output).\n")
    md.append("\n## Top priorities (by impact)\n")
    for i, row in topk_df.iterrows():
        md.append(f"{i+1}. **{row['dimension']}** | current={row['current']:.2f}, bic={row['bic']:.2f}, gap={row['gap_to_bic']:.2f}, impact={row['impact']:.3f}")
    md.append("\n\n## Files\n")
    md.append(f"- {profile_csv.name}: full profile table\n")
    md.append(f"- {topk_csv.name}: top-k priorities\n")
    md.append(f"- siri_profile.png: profile plot\n")
    md.append(f"- siri_impact.png: impact ranking plot\n")

    (out_dir / "siri_anchor_summary.md").write_text("\n".join(md) + "\n", encoding="utf-8")

    print("[siri_anchor] wrote:")
    print(" -", profile_csv)
    print(" -", topk_csv)
    print(" -", meta_json)
    print(" -", out_dir / "siri_profile.png")
    print(" -", out_dir / "siri_impact.png")
    print(" -", out_dir / "siri_anchor_summary.md")


if __name__ == "__main__":
    main()
