"""
Benchmark script: compare RIEC vs pure BIC vs pure CV across regimes.

Usage:
  python -m riec.experiments.run_benchmark
  python -m riec.experiments.run_benchmark --excel Manifest.xlsx --sheet Plants_All --out results.csv

Notes:
- This is a lightweight benchmark to validate the pipeline.
- For a Nature-level paper you will likely extend regimes, baselines, and metrics.
"""
from __future__ import annotations

import argparse
from dataclasses import asdict
from typing import Dict, List, Optional

import numpy as np
import pandas as pd

from riec.io import read_manifest_excel
from riec.measurement import MeasurementMetadata
from riec.models import GroupFixedEffectsWrapper, linear_model, ridge, gbdt
from riec.selection import RIECSelector, SelectionConfig
from riec.world import CofcoWorldGenerator, WorldConfig, OutcomeSpec


def make_toy_manifest(seed: int = 0) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    G = 14
    sizes = rng.integers(10, 40, size=G)
    rows = []
    for g in range(G):
        for i in range(int(sizes[g])):
            rows.append(
                {
                    "board_id": f"B{g:02d}",
                    "automation_star": rng.integers(1, 5),
                    "connectivity_star": rng.integers(1, 5),
                    "intelligence_star": rng.integers(1, 5),
                    "maturity_score": rng.normal(2.0, 0.6),
                    "data_points_total": rng.normal(1200, 500),
                    "auto_capture_rate": rng.uniform(0.3, 0.95),
                }
            )
    return pd.DataFrame(rows)


def pick_feature_cols(df: pd.DataFrame) -> List[str]:
    candidate_features = [
        "automation_star",
        "connectivity_star",
        "intelligence_star",
        "maturity_score",
        "data_points_total",
        "auto_capture_rate",
    ]
    return [c for c in candidate_features if c in df.columns]


def select_with_rule(scores_df: pd.DataFrame, rule: str) -> pd.Series:
    """Pick a single row (model) according to a selection rule.

    If the selector's gatekeeper is active and at least one candidate passes it,
    we restrict selection to those passed candidates (consistent with the selector).
    """

    if "passed_gatekeeper" in scores_df.columns and bool(scores_df["passed_gatekeeper"].any()):
        sdf = scores_df[scores_df["passed_gatekeeper"]].copy()
    else:
        sdf = scores_df.copy()

    if rule == "cv":
        idx = sdf["cv_mse"].idxmin()
    elif rule == "bic":
        idx = sdf["bic"].idxmin()
    elif rule in ("riec", "riec_a"):
        idx = sdf["c_lambda"].idxmin()
    elif rule in ("riec_b", "riec_guard"):
        metric = "c_lambda_b" if "c_lambda_b" in sdf.columns else "c_lambda"
        idx = sdf[metric].idxmin()
    else:
        raise ValueError(rule)

    return sdf.loc[idx]


def mse_on_test(model, X_train, y_train, g_train, X_test, y_test, g_test) -> float:
    m = model.clone().fit(X_train, y_train, groups=g_train)
    pred = m.predict(X_test, groups=g_test)
    return float(np.mean((y_test - pred) ** 2))


def _parse_int_list(s: str) -> List[int]:
    return [int(float(x)) for x in s.split(",") if x.strip() != ""]


def _parse_float_list(s: str) -> List[float]:
    return [float(x) for x in s.split(",") if x.strip() != ""]


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--excel", type=str, default=None, help="Path to manifest Excel (optional).")
    ap.add_argument("--sheet", type=str, default="Plants_All")
    ap.add_argument("--out", type=str, default=None, help="Write results to CSV (optional).")
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument(
        "--preset",
        type=str,
        choices=["quick", "paper"],
        default="quick",
        help=(
            "Benchmark preset. 'quick' is intended to finish fast on a laptop; "
            "'paper' uses heavier settings for final runs."
        ),
    )
    ap.add_argument("--n_list", type=str, default=None, help="Override train n list (comma-separated), e.g. '120,240,480'.")
    ap.add_argument("--icc_list", type=str, default=None, help="Override ICC list (comma-separated), e.g. '0.05,0.25,0.5'.")
    ap.add_argument("--cv_folds", type=int, default=None, help="Override CV folds (e.g. 3 or 5).")
    ap.add_argument("--gbdt_estimators", type=int, default=None, help="Override GBDT n_estimators.")
    ap.add_argument("--test_n", type=int, default=None, help="Override test-set size per regime.")
    ap.add_argument("--n_groups", type=int, default=14, help="Number of groups/clusters in the virtual world.")
    args = ap.parse_args()

    # -----------------------------
    # Preset / overrides
    # -----------------------------
    if args.preset == "quick":
        n_list = [120, 240]
        icc_list = [0.05, 0.25]
        cv_folds = 3
        gbdt_estimators = 120
        test_n = 500
    else:
        n_list = [120, 240, 480]
        icc_list = [0.05, 0.25, 0.50]
        cv_folds = 5
        gbdt_estimators = 300
        test_n = 1500

    if args.n_list:
        n_list = _parse_int_list(args.n_list)
    if args.icc_list:
        icc_list = _parse_float_list(args.icc_list)
    if args.cv_folds is not None:
        cv_folds = int(args.cv_folds)
    if args.gbdt_estimators is not None:
        gbdt_estimators = int(args.gbdt_estimators)
    if args.test_n is not None:
        test_n = int(args.test_n)

    print(
        f"[run_benchmark] preset={args.preset}  n_list={n_list}  icc_list={icc_list}  "
        f"cv_folds={cv_folds}  gbdt_estimators={gbdt_estimators}  test_n={test_n}  n_groups={args.n_groups}",
        flush=True,
    )

    if args.excel:
        manifest = read_manifest_excel(args.excel, sheet=args.sheet)
        if "board_id" not in manifest.columns:
            for cand in ["board_name", "board_name_zh", "专业化公司", "公司", "company"]:
                if cand in manifest.columns:
                    manifest = manifest.rename(columns={cand: "board_id"})
                    break
    else:
        manifest = make_toy_manifest(seed=args.seed)

    feature_cols = pick_feature_cols(manifest)
    group_col = "board_id" if "board_id" in manifest.columns else None
    if group_col is None:
        raise RuntimeError("Need board_id-like group column for benchmark.")

    gen = CofcoWorldGenerator()
    cal = gen.fit(manifest, group_col=group_col, feature_cols=feature_cols, n_latent_types=4, seed=args.seed)

    # Candidate families
    model_families = {
        "Pooled": [
            linear_model(),
            ridge(alpha=1.0),
            gbdt(n_estimators=gbdt_estimators),
        ],
        "GroupFE": [
            GroupFixedEffectsWrapper(linear_model()),
            GroupFixedEffectsWrapper(ridge(alpha=1.0)),
        ],
    }

    selector = RIECSelector(config=SelectionConfig(cv_folds=cv_folds, random_state=args.seed, c_for_lambda=1.0))
    meta = MeasurementMetadata(group_col=group_col)

    regimes = []
    for n in n_list:
        for icc in icc_list:
            regimes.append((n, icc))

    rows: List[Dict[str, float]] = []
    for ridx, (n, icc) in enumerate(regimes):
        print(f"[run_benchmark] Regime {ridx+1}/{len(regimes)}: n={n}, icc={icc}", flush=True)
        # Fix an outcome spec so train/test are comparable
        p = len(feature_cols)
        rng = np.random.default_rng(args.seed + 1000 + ridx)
        outcome = OutcomeSpec(
            beta=rng.normal(0, 1, size=p),
            gamma=rng.normal(0, 1, size=p),
            noise_std=1.0,
            misspec_level=0.25,
            group_y_std=0.5,
        )
        cfg_train = WorldConfig(
            n_groups=args.n_groups,
            n_samples=n,
            icc_target=icc,
            seed=args.seed + ridx,
            misspec_level=outcome.misspec_level,
            group_y_std=outcome.group_y_std,
        )
        train_df, truth_train = gen.sample(cfg_train, cal, outcome_spec=outcome)

        cfg_test = WorldConfig(
            n_groups=args.n_groups,
            n_samples=test_n,
            icc_target=icc,
            seed=args.seed + 10000 + ridx,
            misspec_level=outcome.misspec_level,
            group_y_std=outcome.group_y_std,
        )
        test_df, truth_test = gen.sample(cfg_test, cal, outcome_spec=outcome)

        # Run full scoring once
        res = selector.select_from_dataframe(train_df, feature_cols, "y", meta, model_families)
        scores_df = res.as_dataframe()

        X_train = train_df[feature_cols].to_numpy(float)
        y_train = train_df["y"].to_numpy(float)
        g_train = train_df[group_col].astype(str).to_numpy()

        X_test = test_df[feature_cols].to_numpy(float)
        y_test = test_df["y"].to_numpy(float)
        g_test = test_df[group_col].astype(str).to_numpy()

        # Evaluate each rule
        for rule in ["cv", "bic", "riec", "riec_b"]:
            pick = select_with_rule(scores_df, rule)
            fam = str(pick["family"])
            model_name = str(pick["model"])

            # find the model object
            model_obj = None
            for m in model_families[fam]:
                if m.name == model_name:
                    model_obj = m
                    break
            if model_obj is None:
                model_obj = model_families[fam][0]

            mse = mse_on_test(model_obj, X_train, y_train, g_train, X_test, y_test, g_test)

            rows.append(
                {
                    "regime_n": float(n),
                    "regime_icc": float(icc),
                    "rule": rule,
                    "selected_family": fam,
                    "selected_model": model_name,
                    "test_mse": mse,
                    "manifest_n_eff": float(res.manifest.overall_n_eff),
                    "lambda_weight": float(scores_df["lambda_weight"].iloc[0]),
                    "lambda_weight_used": float(scores_df["lambda_weight_b"].iloc[0] if ("lambda_weight_b" in scores_df.columns and rule=="riec_b") else scores_df["lambda_weight"].iloc[0]),
                    "guard_triggered": bool(scores_df["riec_b_triggered"].iloc[0] if ("riec_b_triggered" in scores_df.columns and rule=="riec_b") else False),
                }
            )

    out_df = pd.DataFrame(rows)
    print(out_df.groupby(["regime_n", "regime_icc", "rule"])["test_mse"].mean().reset_index().to_string(index=False))

    if args.out:
        out_df.to_csv(args.out, index=False)
        print("\nWrote:", args.out)


if __name__ == "__main__":
    main()
