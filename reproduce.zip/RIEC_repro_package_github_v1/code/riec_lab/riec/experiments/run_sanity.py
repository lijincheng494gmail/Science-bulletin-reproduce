"""
Sanity-check script: end-to-end RIEC on a minimal virtual factory world.

Usage:
  python -m riec.experiments.run_sanity
  python -m riec.experiments.run_sanity --excel /path/to/Manifest.xlsx --sheet Plants_All

This script is intentionally small and self-contained.
"""
from __future__ import annotations

import argparse
import numpy as np
import pandas as pd

from riec.io import read_manifest_excel
from riec.measurement import MeasurementMetadata
from riec.models import (
    GroupFixedEffectsWrapper,
    linear_model,
    ridge,
    gbdt,
)
from riec.selection import RIECSelector, SelectionConfig
from riec.world import CofcoWorldGenerator, WorldConfig


def make_toy_manifest(seed: int = 0) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    G = 14
    sizes = rng.integers(10, 40, size=G)
    rows = []
    for g in range(G):
        for i in range(int(sizes[g])):
            rows.append(
                {
                    "board_id": f"B{g:02d}",
                    "automation_star": rng.integers(1, 5),
                    "connectivity_star": rng.integers(1, 5),
                    "intelligence_star": rng.integers(1, 5),
                    "maturity_score": rng.normal(2.0, 0.6),
                    "data_points_total": rng.normal(1200, 500),
                    "auto_capture_rate": rng.uniform(0.3, 0.95),
                }
            )
    return pd.DataFrame(rows)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--excel", type=str, default=None, help="Path to COFCO manifest Excel (optional).")
    ap.add_argument("--sheet", type=str, default="Plants_All", help="Sheet name in manifest Excel.")
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()

    if args.excel:
        manifest = read_manifest_excel(args.excel, sheet=args.sheet)
        if "board_id" not in manifest.columns:
            # try common alternatives
            for cand in ["board_name", "board_name_zh", "专业化公司", "公司", "company"]:
                if cand in manifest.columns:
                    manifest = manifest.rename(columns={cand: "board_id"})
                    break
    else:
        manifest = make_toy_manifest(seed=args.seed)

    # pick some reasonable features
    candidate_features = [
        "automation_star",
        "connectivity_star",
        "intelligence_star",
        "maturity_score",
        "data_points_total",
        "auto_capture_rate",
    ]
    feature_cols = [c for c in candidate_features if c in manifest.columns]
    if not feature_cols:
        raise RuntimeError("No usable feature columns found. Please check the manifest columns.")

    group_col = "board_id" if "board_id" in manifest.columns else None
    if group_col is None:
        raise RuntimeError("No group column found (need board_id or similar).")

    # Fit world calibration
    gen = CofcoWorldGenerator()
    cal = gen.fit(manifest, group_col=group_col, feature_cols=feature_cols, n_latent_types=4, seed=args.seed)

    # Sample a synthetic dataset
    cfg = WorldConfig(n_groups=14, n_samples=300, icc_target=0.35, seed=args.seed, misspec_level=0.25)
    df, truth = gen.sample(cfg, cal)

    # Candidate model families
    model_families = {
        "Pooled": [
            linear_model(),
            ridge(alpha=1.0),
            gbdt(n_estimators=300),
        ],
        "GroupFE": [
            GroupFixedEffectsWrapper(linear_model()),
            GroupFixedEffectsWrapper(ridge(alpha=1.0)),
        ],
    }

    selector = RIECSelector(config=SelectionConfig(cv_folds=5, random_state=args.seed, c_for_lambda=1.0))
    meta = MeasurementMetadata(group_col=group_col)
    result = selector.select_from_dataframe(df, feature_cols=feature_cols, target_col="y", metadata=meta, model_families=model_families)

    print("\n=== Measurement summary ===")
    print("n_rows:", result.manifest.n_rows, "n_groups:", result.manifest.n_groups)
    print("overall_n_eff:", round(result.manifest.overall_n_eff, 2))
    if result.manifest.icc:
        icc_med = np.median(list(result.manifest.icc.values()))
        print("median ICC:", round(float(icc_med), 3))

    print("\n=== Best model ===")
    print("family:", result.best_family)
    print("model:", result.best_model)

    df_scores = result.as_dataframe()
    print("\n=== Top-8 models by C_lambda ===")
    cols_show = ["family", "model", "c_lambda", "bic", "xpe", "cv_mse", "r2_full", "k", "n_eff"]
    print(df_scores[cols_show].head(8).to_string(index=False))


if __name__ == "__main__":
    main()
