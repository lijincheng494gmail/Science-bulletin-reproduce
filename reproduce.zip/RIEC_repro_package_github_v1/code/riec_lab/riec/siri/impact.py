"""Deterministic impact scoring for SIRI 16 dimensions.

This reproduces the core logic in your local HTML tool:
  - build cost and KPI leverage scores using R_cost / R_kpi
  - combine with a 'gap-to-BIC' component
  - weight components by W = {cost, kpi, gap}

For 'Use A (diagnostic language anchor)', the goal is not to claim SIRI is
your *statistical* contribution. It's an *interface/ontology layer*:
  - you output results using SIRI's standard 16-dimension vocabulary
  - readers/managers can understand "what to improve" without reading
    the full statistical machinery.

So: keep it deterministic, transparent, and auditable.
"""

from __future__ import annotations

from typing import Any, Dict, Iterable, List, Optional, Tuple

import numpy as np
import pandas as pd


def _normalize_sum(v: np.ndarray) -> np.ndarray:
    s = float(np.sum(v))
    if abs(s) < 1e-12:
        return np.zeros_like(v)
    return v / s


def siri_impact_table(
    siri: Dict[str, Any],
    maturity: Optional[Iterable[float]] = None,
    cost_weights: Optional[Iterable[float]] = None,
    kpi_weights: Optional[Iterable[float]] = None,
    W: Optional[Dict[str, float]] = None,
) -> pd.DataFrame:
    """Return a DataFrame with SIRI profile + impact components.

    Parameters
    ----------
    siri:
        Output of `parse_siri_html`.
    maturity:
        Length-16 maturity values. If None, uses default from HTML.
    cost_weights:
        Length-(#cost items) weights. If None, uses default from HTML.
    kpi_weights:
        Length-(#kpi items) weights. If None, uses uniform weights.
    W:
        dict with keys {cost,kpi,gap}. If None, uses default from HTML.

    Returns
    -------
    DataFrame columns:
        dimension, current, avg, bic, gap_to_bic,
        c_component, k_component, p_component, impact_raw, impact
    where impact is normalized to max=1 for easy ranking/plots.
    """
    dims = list(siri["dimensions"])
    avg = np.asarray(siri["avg"], dtype=float)
    bic = np.asarray(siri["bic"], dtype=float)

    m = np.asarray(list(maturity) if maturity is not None else siri["default_maturity"], dtype=float)
    if m.shape[0] != 16:
        raise ValueError("maturity must be length 16")

    r_cost = np.asarray(siri["R_cost"], dtype=float)  # (n_cost, 16)
    r_kpi = np.asarray(siri["R_kpi"], dtype=float)   # (n_kpi, 16)

    # weights
    w_cost = np.asarray(list(cost_weights) if cost_weights is not None else siri["default_cost_weights"], dtype=float)
    if w_cost.shape[0] != r_cost.shape[0]:
        raise ValueError("cost_weights length mismatch")
    w_cost = w_cost / max(w_cost.sum(), 1e-12)

    if kpi_weights is None:
        w_kpi = np.ones(r_kpi.shape[0], dtype=float) / float(r_kpi.shape[0])
    else:
        w_kpi = np.asarray(list(kpi_weights), dtype=float)
        if w_kpi.shape[0] != r_kpi.shape[0]:
            raise ValueError("kpi_weights length mismatch")
        w_kpi = w_kpi / max(w_kpi.sum(), 1e-12)

    W_use = dict(siri.get("W", {"cost": 1/3, "kpi": 1/3, "gap": 1/3}))
    if W is not None:
        W_use.update(W)

    # components across 16 dims
    c_raw = r_cost.T @ w_cost   # (16,)
    k_raw = r_kpi.T @ w_kpi     # (16,)
    p_raw = bic - m             # (16,)

    c = _normalize_sum(c_raw)
    k = _normalize_sum(k_raw)
    p = _normalize_sum(p_raw)

    impact_raw = W_use.get("cost", 0.0) * c + W_use.get("kpi", 0.0) * k + W_use.get("gap", 0.0) * p
    # normalize for display (max=1)
    mx = float(np.max(impact_raw)) if impact_raw.size else 1.0
    impact = impact_raw / (mx if mx > 1e-12 else 1.0)

    df = pd.DataFrame({
        "dimension": dims,
        "current": m,
        "avg": avg,
        "bic": bic,
        "gap_to_bic": bic - m,
        "c_component": c,
        "k_component": k,
        "p_component": p,
        "impact_raw": impact_raw,
        "impact": impact,
    })
    return df
