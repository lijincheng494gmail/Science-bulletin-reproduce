"""Parse a SIRI assessment HTML file into machine-readable inputs.

The project already ships a local HTML tool (e.g., 智能制造评估.html).
That file contains JS constants like:
  - DIMENSIONS, COST_ITEMS, KPI_ITEMS
  - AVG, BIC, DEFAULT_M, DEFAULT_COST
  - R_cost, R_kpi (matrices)
  - W = {cost:..., kpi:..., gap:...}

We extract these constants so that downstream scripts can:
  - reproduce the same scoring deterministically
  - generate SIRI-anchored tables/figures for your paper (SB-friendly)

No external dependencies required.
"""

from __future__ import annotations

import ast
import re
from pathlib import Path
from typing import Any, Dict, List, Optional


def _extract_bracket_array(html: str, const_name: str) -> Any:
    """Extract a JS array assigned to `const <name> = [...]`.

    This is a robust-ish extractor:
      1) locate 'const NAME = [' 
      2) bracket-match until outermost array closes
      3) strip JS comments (/* */ and //)
      4) normalize some JS literals to Python literals
      5) ast.literal_eval
    """
    m = re.search(rf"const\s+{re.escape(const_name)}\s*=\s*\[", html)
    if not m:
        raise ValueError(f"Cannot find const {const_name} = [...] in HTML")

    start = m.end() - 1  # position at '['
    depth = 0
    end: Optional[int] = None
    for i, ch in enumerate(html[start:], start=start):
        if ch == "[":
            depth += 1
        elif ch == "]":
            depth -= 1
            if depth == 0:
                end = i + 1
                break

    if end is None:
        raise ValueError(f"Unclosed array for {const_name}")

    arr_str = html[start:end]
    # Strip JS comments
    arr_str = re.sub(r"/\*[\s\S]*?\*/", "", arr_str)
    arr_str = re.sub(r"//.*", "", arr_str)
    # Normalize odd hyphen
    arr_str = arr_str.replace("\u2011", "-")
    # Normalize JS -> Python
    arr_str = arr_str.replace("null", "None")
    arr_str = arr_str.replace("true", "True")
    arr_str = arr_str.replace("false", "False")
    # Remove trailing commas before closing brackets
    arr_str = re.sub(r",\s*]", "]", arr_str)

    return ast.literal_eval(arr_str)


def _extract_js_object_W(html: str) -> Dict[str, float]:
    """Extract const W = {cost:0.6,kpi:0.2,gap:0.2}."""
    m = re.search(r"const\s+W\s*=\s*\{([^}]+)\}", html)
    if not m:
        # fall back to equal weights
        return {"cost": 1/3, "kpi": 1/3, "gap": 1/3}
    body = m.group(1)
    out: Dict[str, float] = {}
    for part in body.split(","):
        if ":" not in part:
            continue
        k, v = part.split(":", 1)
        k = k.strip()
        v = v.strip()
        try:
            out[k] = float(v)
        except Exception:
            pass
    # ensure keys
    for k in ["cost", "kpi", "gap"]:
        out.setdefault(k, 0.0)
    return out


def parse_siri_html(html_path: str | Path) -> Dict[str, Any]:
    """Parse a local SIRI HTML assessment export into arrays/matrices."""
    p = Path(html_path)
    if not p.exists():
        raise FileNotFoundError(f"SIRI HTML not found: {p}")

    html = p.read_text(encoding="utf-8", errors="ignore")

    dims = _extract_bracket_array(html, "DIMENSIONS")
    cost_items = _extract_bracket_array(html, "COST_ITEMS")
    kpi_items = _extract_bracket_array(html, "KPI_ITEMS")

    avg = _extract_bracket_array(html, "AVG")
    bic = _extract_bracket_array(html, "BIC")
    default_m = _extract_bracket_array(html, "DEFAULT_M")
    default_cost = _extract_bracket_array(html, "DEFAULT_COST")

    r_cost = _extract_bracket_array(html, "R_cost")
    r_kpi = _extract_bracket_array(html, "R_kpi")

    w = _extract_js_object_W(html)

    # Basic sanity checks
    if len(dims) != 16:
        raise ValueError(f"Expected 16 SIRI dimensions, got {len(dims)}")
    if len(avg) != 16 or len(bic) != 16 or len(default_m) != 16:
        raise ValueError("AVG/BIC/DEFAULT_M must be length-16 vectors")

    return {
        "dimensions": dims,
        "cost_items": cost_items,
        "kpi_items": kpi_items,
        "avg": avg,
        "bic": bic,
        "default_maturity": default_m,
        "default_cost_weights": default_cost,
        "R_cost": r_cost,
        "R_kpi": r_kpi,
        "W": w,
    }
