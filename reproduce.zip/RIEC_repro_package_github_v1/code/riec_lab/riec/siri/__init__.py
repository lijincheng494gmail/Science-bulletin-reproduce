"""SIRI utilities (diagnostic language anchor).

This module provides lightweight parsing and deterministic computations
derived from a SIRI assessment HTML export (your local tool/page).
"""

from .html_parser import parse_siri_html
from .impact import siri_impact_table
