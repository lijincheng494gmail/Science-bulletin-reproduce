from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd
from sklearn.cluster import KMeans


def _rng(seed: int) -> np.random.Generator:
    return np.random.default_rng(int(seed))


def _corr_from_cov(cov: np.ndarray, eps: float = 1e-12) -> np.ndarray:
    d = np.sqrt(np.clip(np.diag(cov), eps, None))
    return cov / np.outer(d, d)


def _make_psd(cov: np.ndarray, eps: float = 1e-8) -> np.ndarray:
    """
    Ensure covariance is positive semi-definite by eigenvalue clipping.
    """
    cov = 0.5 * (cov + cov.T)
    w, V = np.linalg.eigh(cov)
    w = np.clip(w, eps, None)
    return (V * w) @ V.T


def estimate_between_within_cov(
    X: np.ndarray,
    groups: np.ndarray,
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Decompose covariance into between-group and within-group components.
    """
    X = np.asarray(X, dtype=float)
    groups = np.asarray(groups)

    mask = np.isfinite(X).all(axis=1)
    X = X[mask]
    groups = groups[mask]
    if X.shape[0] < 3:
        p = X.shape[1]
        return np.zeros((p, p)), np.cov(X.T) if X.shape[0] >= 2 else np.eye(p)

    uniq, gi = np.unique(groups, return_inverse=True)
    G = len(uniq)
    n = X.shape[0]
    p = X.shape[1]

    overall = X.mean(axis=0)
    means = np.vstack([X[gi == j].mean(axis=0) for j in range(G)])
    n_g = np.bincount(gi).astype(float)

    # Between covariance (weighted)
    centered_means = means - overall
    cov_b = (centered_means.T * n_g) @ centered_means / max(1.0, (n - 1.0))

    # Within covariance
    cov_w_num = np.zeros((p, p), dtype=float)
    dfw = 0.0
    for j in range(G):
        Xj = X[gi == j]
        if Xj.shape[0] <= 1:
            continue
        cj = Xj - Xj.mean(axis=0)
        cov_w_num += cj.T @ cj
        dfw += Xj.shape[0] - 1
    cov_w = cov_w_num / max(1.0, dfw)

    return _make_psd(cov_b), _make_psd(cov_w)


@dataclass
class WorldCalibration:
    """
    Calibration parameters estimated from a real manifest.
    """
    feature_cols: List[str]
    group_col: str

    overall_mean: np.ndarray  # (p,)
    cov_between: np.ndarray   # (p,p)
    cov_within: np.ndarray    # (p,p)

    # latent types
    latent_type_weights: np.ndarray  # (K,)
    latent_type_means: np.ndarray    # (K,p)

    # cluster size distribution (empirical)
    group_size_values: np.ndarray    # unique sizes
    group_size_probs: np.ndarray     # probabilities


@dataclass
class OutcomeSpec:
    """
    Defines a synthetic outcome y = f(X, z, g) + noise, used for benchmarking selection.

    y = X @ beta + misspec_level * sin(X @ gamma) + group_y + eps
    """
    beta: np.ndarray
    gamma: np.ndarray
    noise_std: float = 1.0
    misspec_level: float = 0.0
    group_y_std: float = 0.0


@dataclass
class WorldConfig:
    """
    Controls one simulation regime.

    n_groups:
        Number of clusters/groups to generate.
    n_samples:
        Total number of factories/sites.
    icc_target:
        Target marginal ICC for features (roughly).
    """
    n_groups: int = 14
    n_samples: int = 200
    icc_target: float = 0.25
    n_latent_types: int = 4
    seed: int = 0

    # outcome
    outcome_noise_std: float = 1.0
    misspec_level: float = 0.2
    group_y_std: float = 0.5


class CofcoWorldGenerator:
    """
    COFCO-inspired virtual factory world generator.

    Design goals:
    - Strong hierarchy: group effects induce ICC.
    - Strong correlations: within-feature covariance.
    - Latent factory types: mixture components for X.
    - Tunable regimes: N / ICC / noise / misspecification.

    Workflow:
      1) Fit calibration from a real manifest (Excel).
      2) Sample synthetic datasets for benchmarking.

    Example:
        gen = CofcoWorldGenerator()
        cal = gen.fit(manifest_df, group_col="board_id", feature_cols=[...])
        df, truth = gen.sample(WorldConfig(n_samples=300, icc_target=0.4), cal)
    """

    def fit(
        self,
        manifest_df: pd.DataFrame,
        group_col: str,
        feature_cols: Sequence[str],
        n_latent_types: int = 4,
        seed: int = 0,
    ) -> WorldCalibration:
        df = manifest_df.copy()
        df = df.dropna(subset=[group_col])
        for c in feature_cols:
            df[c] = pd.to_numeric(df[c], errors="coerce")
        df = df.dropna(subset=list(feature_cols))
        if df.empty:
            raise ValueError("No usable rows after cleaning. Check feature_cols/group_col.")

        X = df[list(feature_cols)].to_numpy(dtype=float)
        groups = df[group_col].astype(str).to_numpy()

        cov_b, cov_w = estimate_between_within_cov(X, groups)
        overall_mean = X.mean(axis=0)

        # Latent types via KMeans on centered X
        K = int(max(2, n_latent_types))
        K = int(min(K, max(2, int(np.sqrt(len(df))))))
        km = KMeans(n_clusters=K, n_init="auto", random_state=seed)
        labels = km.fit_predict(X)
        weights = np.bincount(labels).astype(float)
        weights = weights / weights.sum()
        means = np.vstack([X[labels == k].mean(axis=0) for k in range(K)])

        # cluster size empirical distribution
        uniq, counts = np.unique(groups, return_counts=True)
        size_vals, size_counts = np.unique(counts, return_counts=True)
        size_probs = size_counts.astype(float) / size_counts.sum()

        return WorldCalibration(
            feature_cols=list(feature_cols),
            group_col=str(group_col),
            overall_mean=overall_mean,
            cov_between=cov_b,
            cov_within=cov_w,
            latent_type_weights=weights,
            latent_type_means=means,
            group_size_values=size_vals.astype(int),
            group_size_probs=size_probs,
        )

    def sample(
        self,
        config: WorldConfig,
        calibration: WorldCalibration,
        outcome_spec: Optional[OutcomeSpec] = None,
    ) -> Tuple[pd.DataFrame, Dict[str, Any]]:
        rng = _rng(config.seed)

        p = len(calibration.feature_cols)
        G = int(max(1, config.n_groups))
        n = int(max(G, config.n_samples))
        K = int(max(2, min(config.n_latent_types, calibration.latent_type_means.shape[0])))

        # Sample group sizes then trim/pad to total n
        size_vals = calibration.group_size_values
        size_probs = calibration.group_size_probs
        sizes = rng.choice(size_vals, size=G, replace=True, p=size_probs)
        # Adjust to sum to n
        total = int(sizes.sum())
        if total <= 0:
            sizes = np.array([n // G] * G, dtype=int)
            total = sizes.sum()
        # Scale sizes proportionally to hit n
        sizes = np.maximum(1, np.round(sizes * (n / total)).astype(int))
        # Fix rounding drift
        drift = int(n - sizes.sum())
        if drift != 0:
            for i in range(abs(drift)):
                j = i % G
                sizes[j] += 1 if drift > 0 else -1
                sizes[j] = max(1, sizes[j])

        groups = np.concatenate([[f"G{g:02d}"] * int(sizes[g]) for g in range(G)])
        groups = groups[:n]

        # Build group-effect covariance to match ICC target (diagonal match, correlation from cov_between)
        cov_w = calibration.cov_within
        cov_w = _make_psd(cov_w)
        var_w = np.clip(np.diag(cov_w), 1e-8, None)

        icc = float(np.clip(config.icc_target, 0.0, 0.95))
        var_u = icc / max(1e-6, (1.0 - icc)) * var_w
        # correlation structure from empirical between covariance
        Rb = _corr_from_cov(calibration.cov_between)
        Rb = np.nan_to_num(Rb, nan=0.0, posinf=0.0, neginf=0.0)
        # PSD fix
        Rb = _make_psd(Rb)
        D = np.diag(np.sqrt(var_u))
        cov_u = D @ Rb @ D
        cov_u = _make_psd(cov_u)

        # Sample group effects
        uniq_groups, gi = np.unique(groups, return_inverse=True)
        U = rng.multivariate_normal(mean=np.zeros(p), cov=cov_u, size=len(uniq_groups))
        u_i = U[gi]

        # Sample latent types and within noise
        w = calibration.latent_type_weights[:K]
        w = w / w.sum()
        z = rng.choice(np.arange(K), size=n, p=w)

        means = calibration.latent_type_means[:K]
        mu_i = means[z]

        E = rng.multivariate_normal(mean=np.zeros(p), cov=cov_w, size=n)

        X = mu_i + u_i + E

        df = pd.DataFrame(X, columns=calibration.feature_cols)
        df[calibration.group_col] = groups
        df["latent_type"] = z

        # Outcome
        if outcome_spec is None:
            beta = rng.normal(0, 1, size=p)
            gamma = rng.normal(0, 1, size=p)
            outcome_spec = OutcomeSpec(
                beta=beta,
                gamma=gamma,
                noise_std=float(config.outcome_noise_std),
                misspec_level=float(config.misspec_level),
                group_y_std=float(config.group_y_std),
            )

        # Group effect for outcome (separate from feature group effect)
        gy = rng.normal(0.0, outcome_spec.group_y_std, size=len(uniq_groups))
        gy_i = gy[gi]

        y_lin = X @ outcome_spec.beta
        y_nonlin = outcome_spec.misspec_level * np.sin(X @ outcome_spec.gamma)
        y = y_lin + y_nonlin + gy_i + rng.normal(0.0, outcome_spec.noise_std, size=n)

        df["y"] = y

        truth: Dict[str, Any] = {
            "config": config,
            "outcome_spec": outcome_spec,
            "icc_target": icc,
            "n_groups": len(uniq_groups),
            "feature_cols": calibration.feature_cols,
            "group_col": calibration.group_col,
            "latent_K": K,
        }
        return df, truth
