"""RIEC: Robust, Interpretable, Explainable & Controllable framework.

This package is organized around the RIEC pipeline:

1) Measurement: clean and quantify industrial survey/manifest data, estimate cluster correlation
   (ICC) and effective sample size (n_eff), and produce model-structure hints.
2) Modeling: define candidate model families (structure C + learner f).
3) Selection: combine information criteria (BIC using n_eff) with cross-validated predictive
   improvement (XPE) via the C_λ score, and run a two-stage structure-first selection.
4) Decision & Audit: optional utilities to produce auditable recommendations and uncertainty
   diagnostics.

The package also ships a COFCO-inspired "virtual factory world" generator for benchmarking.
"""

from .measurement import MeasurementEngine, MeasurementManifest, MeasurementMetadata, ModelHints
from .selection import RIECSelector, SelectionConfig, SelectionResult

__all__ = [
    "MeasurementEngine",
    "MeasurementManifest",
    "MeasurementMetadata",
    "ModelHints",
    "RIECSelector",
    "SelectionConfig",
    "SelectionResult",
]
