from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd
from sklearn.model_selection import GroupKFold, KFold

from .measurement import MeasurementEngine, MeasurementManifest, MeasurementMetadata
from .models.base import ModelScore, gaussian_bic_from_rss, gaussian_loglik_from_rss, CandidateRegressor


def _r2(y: np.ndarray, yhat: np.ndarray) -> float:
    y = np.asarray(y, dtype=float)
    yhat = np.asarray(yhat, dtype=float)
    mask = np.isfinite(y) & np.isfinite(yhat)
    y = y[mask]
    yhat = yhat[mask]
    if y.size < 2:
        return float("nan")
    ss_res = float(np.sum((y - yhat) ** 2))
    ss_tot = float(np.sum((y - y.mean()) ** 2))
    if ss_tot <= 1e-12:
        return 0.0
    return float(1.0 - ss_res / ss_tot)


def _cv_mse(
    model: CandidateRegressor,
    X: np.ndarray,
    y: np.ndarray,
    groups: Optional[np.ndarray],
    n_splits: int,
    random_state: int,
    use_group_cv: bool,
) -> Tuple[float, float]:
    """
    Returns (cv_mse, baseline_cv_mse).
    Baseline = mean predictor fitted on train fold.
    """
    y = np.asarray(y, dtype=float)
    X = np.asarray(X, dtype=float)

    if use_group_cv and groups is not None:
        splitter = GroupKFold(n_splits=n_splits)
        splits = splitter.split(X, y, groups=groups)
    else:
        splitter = KFold(n_splits=n_splits, shuffle=True, random_state=random_state)
        splits = splitter.split(X, y)

    mse_list: List[float] = []
    base_list: List[float] = []
    for train_idx, test_idx in splits:
        Xtr, Xte = X[train_idx], X[test_idx]
        ytr, yte = y[train_idx], y[test_idx]
        gtr = groups[train_idx] if groups is not None else None
        gte = groups[test_idx] if groups is not None else None

        m = model.clone()
        m.fit(Xtr, ytr, groups=gtr)
        pred = m.predict(Xte, groups=gte)
        mse = float(np.mean((yte - pred) ** 2))
        mse_list.append(mse)

        base = float(np.mean(ytr))
        base_mse = float(np.mean((yte - base) ** 2))
        base_list.append(base_mse)

    return float(np.mean(mse_list)), float(np.mean(base_list))


@dataclass(frozen=True)
class SelectionConfig:
    """
    Configuration for RIEC model selection.

    c_for_lambda:
        C_λ uses λ(n_eff) = c / log(n_eff). Larger c => more weight on predictive improvement.
    """
    cv_folds: int = 5
    random_state: int = 0

    # RIEC hyperparameters
    c_for_lambda: float = 1.0
    eps: float = 1e-12

    gatekeeper_r2_min: float = -0.05  # allow weak models but filter pathological ones
    use_group_cv: bool = True

    # --- Guarded "B version" (optional) ---
    # If the vanilla RIEC choice looks suspicious (e.g., much worse CV risk than the best candidate),
    # we trigger ONE retry with a boosted lambda weight and an optional CV gate.
    #
    # Trigger if:
    #   - cv_mse(best_by_c_lambda) > guard_fail_cv_factor * min_cv_mse  OR
    #   - overfit_ratio(best)      > guard_overfit_ratio               OR
    #   - xpe(best)                < guard_xpe_min
    #
    # Retry behaviour:
    #   - lambda_weight_b = lambda_weight * guard_lambda_boost
    #   - c_lambda_b_raw computed with lambda_weight_b
    #   - optionally keep only models within guard_gate_cv_factor * min_cv_mse (and passed_gatekeeper)
    guard_fail_cv_factor: float = 1.5
    guard_gate_cv_factor: float = 1.25
    guard_lambda_boost: float = 3.0
    guard_overfit_ratio: float = 8.0
    guard_xpe_min: float = 1.0



@dataclass
class SelectionResult:
    best_family: str
    best_model: str
    best_estimator: CandidateRegressor
    manifest: MeasurementManifest
    config: SelectionConfig
    scores: List[ModelScore]

    def as_dataframe(self) -> pd.DataFrame:
        """
        Convert per-model scores into a pandas DataFrame, and compute a few
        derived diagnostics + an optional "B-version" guarded criterion.

        Added columns:
          - train_mse        : rss_full / n_rows
          - overfit_ratio    : cv_mse / max(train_mse, eps)
          - lambda_weight_b  : lambda_weight (or boosted)
          - c_lambda_b_raw   : C_lambda computed with lambda_weight_b (if triggered)
          - c_lambda_b       : guarded C_lambda (may apply CV gate)
          - riec_b_triggered : whether the guard triggered (same value for all rows)
        """
        df = pd.DataFrame([s.__dict__ for s in self.scores])
        if df.empty:
            return df

        # --- Derived diagnostics ---
        n_rows = getattr(self.manifest, "n_rows", None)
        if isinstance(n_rows, (int, float)) and n_rows and n_rows > 0 and "rss_full" in df.columns:
            df["train_mse"] = df["rss_full"] / float(n_rows)
            df["overfit_ratio"] = df["cv_mse"] / np.maximum(df["train_mse"], float(self.config.eps))
        else:
            df["train_mse"] = np.nan
            df["overfit_ratio"] = np.nan

        # --- Guarded "B version" ---
        df["lambda_weight_b"] = df["lambda_weight"]
        df["c_lambda_b_raw"] = df["c_lambda"]
        df["c_lambda_b"] = df["c_lambda"]
        df["riec_b_triggered"] = False

        # Determine the candidate pool (respect the existing gatekeeper if any model passes it)
        if "passed_gatekeeper" in df.columns:
            pool_mask = df["passed_gatekeeper"].astype(bool)
            pool_df = df[pool_mask] if pool_mask.any() else df
        else:
            pool_mask = pd.Series([True] * len(df))
            pool_df = df

        if not pool_df.empty:
            min_cv = float(pool_df["cv_mse"].min())
            base_idx = int(pool_df["c_lambda"].idxmin())

            base_cv = float(df.loc[base_idx, "cv_mse"])
            base_xpe = float(df.loc[base_idx, "xpe"])
            base_overfit = float(df.loc[base_idx, "overfit_ratio"]) if "overfit_ratio" in df.columns else float("nan")

            trigger = (base_cv > float(self.config.guard_fail_cv_factor) * min_cv) or (
                base_xpe < float(self.config.guard_xpe_min)
            )
            if not np.isnan(base_overfit):
                trigger = trigger or (base_overfit > float(self.config.guard_overfit_ratio))

            if trigger:
                df["riec_b_triggered"] = True
                df["lambda_weight_b"] = df["lambda_weight"] * float(self.config.guard_lambda_boost)

                df["c_lambda_b_raw"] = df["bic"] + df["lambda_weight_b"] * np.log(
                    1.0 / np.maximum(df["xpe"], float(self.config.eps))
                )

                gate_mask = df["cv_mse"] <= float(self.config.guard_gate_cv_factor) * min_cv
                # Keep the old gatekeeper behaviour consistent
                if "passed_gatekeeper" in df.columns and pool_mask.any():
                    gate_mask = gate_mask & df["passed_gatekeeper"].astype(bool)

                df["c_lambda_b"] = df["c_lambda_b_raw"].where(gate_mask, np.inf)
                if np.isinf(df["c_lambda_b"]).all():
                    # Fallback: no CV-gated candidate survived; keep boosted criterion without the gate.
                    df["c_lambda_b"] = df["c_lambda_b_raw"]

        return df.sort_values("c_lambda").reset_index(drop=True)



class RIECSelector:
    """
    Selection layer: compute BIC(n_eff), XPE, and combined C_λ score.

    Key definitions (regression):
      baseline_cv_mse = CV MSE of mean predictor
      model_cv_mse    = CV MSE of candidate model
      XPE = baseline_cv_mse / model_cv_mse  (bigger is better)

      BIC = -2 loglik + k log(n_eff)
      λ(n_eff) = c / log(n_eff)
      C_λ = BIC + λ * log(1 / XPE)

    Then select the model with minimal C_λ (after an optional gatekeeper).
    """

    def __init__(self, config: Optional[SelectionConfig] = None, measurement_engine: Optional[MeasurementEngine] = None):
        self.config = config or SelectionConfig()
        self.measurement_engine = measurement_engine or MeasurementEngine(random_state=self.config.random_state)

    def select_from_dataframe(
        self,
        df: pd.DataFrame,
        feature_cols: Sequence[str],
        target_col: str,
        metadata: MeasurementMetadata,
        model_families: Dict[str, Sequence[CandidateRegressor]],
    ) -> SelectionResult:
        """
        Convenience entrypoint that runs MeasurementEngine then selects a model.
        """
        cleaned, manifest, _hints = self.measurement_engine.run(df, metadata, feature_cols=list(feature_cols))
        X, y, groups = self._build_xy(cleaned, feature_cols, target_col, metadata)
        return self.select(X, y, groups=groups, manifest=manifest, model_families=model_families)

    def select(
        self,
        X: np.ndarray,
        y: np.ndarray,
        groups: Optional[np.ndarray],
        manifest: Optional[MeasurementManifest],
        model_families: Dict[str, Sequence[CandidateRegressor]],
    ) -> SelectionResult:
        if manifest is None:
            # fallback
            manifest = MeasurementManifest(
                n_rows=int(len(y)),
                n_groups=int(len(np.unique(groups))) if groups is not None else 1,
                group_col=None,
                group_sizes={"__all__": int(len(y))},
                missing_rate={},
                icc={},
                snr={},
                n_eff={},
                overall_n_eff=float(max(2.0, len(y))),
                corr_mean_abs=0.0,
                corr_max_abs=0.0,
            )

        n_eff = float(max(2.0, manifest.overall_n_eff))
        # λ schedule: more weight on prediction when n_eff small
        lambda_weight = float(self.config.c_for_lambda / np.log(max(2.0, n_eff)))

        scores: List[ModelScore] = []
        n_features = int(X.shape[1])
        n_groups = int(len(np.unique(groups))) if groups is not None else 1

        for fam_name, models in model_families.items():
            for model in models:
                cv_mse, base_mse = _cv_mse(
                    model=model,
                    X=X,
                    y=y,
                    groups=groups,
                    n_splits=self.config.cv_folds,
                    random_state=self.config.random_state,
                    use_group_cv=self.config.use_group_cv,
                )
                xpe = float(base_mse / (cv_mse + self.config.eps))  # >1 is better than baseline
                xpe = float(max(self.config.eps, xpe))

                # fit on full data for likelihood/IC
                m_full = model.clone().fit(X, y, groups=groups)
                yhat = m_full.predict(X, groups=groups)
                rss = float(np.sum((y - yhat) ** 2))
                ll = gaussian_loglik_from_rss(rss=rss, n=int(max(1, round(n_eff))))
                k = int(model.complexity(n_features=n_features, n_groups=n_groups))
                bic = gaussian_bic_from_rss(rss=rss, n_eff=n_eff, k=k)
                r2_full = _r2(y, yhat)

                passed = bool(np.isfinite(r2_full) and (r2_full >= self.config.gatekeeper_r2_min))

                # combined score
                # Good xpe (>1) => log(1/xpe)<0 => reduces C_λ (good).
                c_lambda = float(bic + lambda_weight * np.log(1.0 / xpe))

                scores.append(
                    ModelScore(
                        family=fam_name,
                        model=model.name,
                        k=k,
                        n_eff=n_eff,
                        cv_mse=float(cv_mse),
                        baseline_cv_mse=float(base_mse),
                        xpe=float(xpe),
                        rss_full=float(rss),
                        loglik_full=float(ll),
                        bic=float(bic),
                        lambda_weight=float(lambda_weight),
                        c_lambda=float(c_lambda),
                        r2_full=float(r2_full),
                        passed_gatekeeper=passed,
                        extra={"gatekeeper_r2_min": self.config.gatekeeper_r2_min},
                    )
                )

        # Gatekeeper filtering: if all fail, keep all
        passed_scores = [s for s in scores if s.passed_gatekeeper]
        pool = passed_scores if passed_scores else scores

        # Two-stage: pick best in each family, then best across families
        best_by_family: Dict[str, ModelScore] = {}
        for s in pool:
            if (s.family not in best_by_family) or (s.c_lambda < best_by_family[s.family].c_lambda):
                best_by_family[s.family] = s

        best = min(best_by_family.values(), key=lambda s: s.c_lambda)

        # Refit best estimator on full data for output
        # Find the model object again (by name)
        best_model_obj: Optional[CandidateRegressor] = None
        for m in model_families[best.family]:
            if m.name == best.model:
                best_model_obj = m
                break
        if best_model_obj is None:
            best_model_obj = model_families[best.family][0]

        best_estimator = best_model_obj.clone().fit(X, y, groups=groups)

        return SelectionResult(
            best_family=best.family,
            best_model=best.model,
            best_estimator=best_estimator,
            manifest=manifest,
            config=self.config,
            scores=scores,
        )

    def _build_xy(
        self,
        df: pd.DataFrame,
        feature_cols: Sequence[str],
        target_col: str,
        metadata: MeasurementMetadata,
    ) -> Tuple[np.ndarray, np.ndarray, Optional[np.ndarray]]:
        X = df[list(feature_cols)].to_numpy(dtype=float)
        y = df[target_col].to_numpy(dtype=float)
        groups = None
        if metadata.group_col and metadata.group_col in df.columns:
            groups = df[metadata.group_col].astype(str).to_numpy()
        return X, y, groups
