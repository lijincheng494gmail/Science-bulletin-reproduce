from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Iterable, Iterator, List, Optional, Tuple

import re
import numpy as np
import pandas as pd
from docx import Document
from docx.document import Document as _Document
from docx.table import Table
from docx.text.paragraph import Paragraph
from docx.oxml.table import CT_Tbl
from docx.oxml.text.paragraph import CT_P


def count_stars(s: Any) -> Optional[int]:
    if s is None:
        return None
    ss = str(s).strip()
    if not ss:
        return None
    if "★" in ss:
        return int(ss.count("★"))
    m = re.search(r"(\d+)", ss)
    if m:
        return int(m.group(1))
    return None


def read_manifest_excel(
    path: str,
    sheet: str = "Plants_All",
) -> pd.DataFrame:
    """
    Read a COFCO manifest Excel file.

    The project uses an aggregated manifest workbook with multiple sheets:
      - Plants_All: all units (wide columns)
      - Plants_Core: deep-survey subset
      - Boards: professional company list
      - etc.

    Returns a DataFrame with best-effort type coercions.
    """
    df = pd.read_excel(path, sheet_name=sheet, engine="openpyxl")
    # Convert star columns if present
    for c in df.columns:
        if isinstance(c, str) and ("star" in c.lower() or "水平" in c or "★" in c):
            df[c] = df[c].map(count_stars)
    return df


# -------- docx parsing helpers --------

def iter_block_items(parent: _Document) -> Iterator[Paragraph | Table]:
    """
    Yield each paragraph and table child within parent, in document order.
    """
    parent_elm = parent.element.body
    for child in parent_elm.iterchildren():
        if isinstance(child, CT_P):
            yield Paragraph(child, parent)
        elif isinstance(child, CT_Tbl):
            yield Table(child, parent)


def table_to_matrix(table: Table) -> List[List[str]]:
    return [[cell.text.strip() for cell in row.cells] for row in table.rows]


def parse_tech_level_table(matrix: List[List[str]]) -> Optional[Dict[str, int]]:
    """
    Parse a "技术水平评估" table if it matches the expected 3-column layout.

    Returns dict like {"自动化": 3, "网联化": 2, "智能化": 1}.
    """
    if not matrix or len(matrix) < 2:
        return None
    header = matrix[0]
    # Must contain 技术维度/现状描述/水平 (or close)
    header_join = "|".join(header)
    if "技术维度" not in header_join:
        return None
    # find column indices
    try:
        i_dim = header.index("技术维度")
    except ValueError:
        i_dim = 0
    # "水平" column can be called "水平" or "评级"
    i_lvl = None
    for cand in ["水平", "评级", "得分"]:
        if cand in header:
            i_lvl = header.index(cand)
            break
    if i_lvl is None:
        # assume last col
        i_lvl = len(header) - 1

    out: Dict[str, int] = {}
    for row in matrix[1:]:
        if len(row) <= max(i_dim, i_lvl):
            continue
        dim = row[i_dim].strip()
        lvl = count_stars(row[i_lvl])
        if dim and (lvl is not None):
            out[dim] = int(lvl)
    return out if out else None


def parse_reports_docx(path: str) -> pd.DataFrame:
    """
    Parse the aggregated report docx and extract:
      - factory title (nearest preceding heading)
      - star-level technical ratings (自动化/网联化/智能化) where present

    Note: This is a best-effort extractor; the doc may have inconsistent formatting.
    """
    doc = Document(path)

    current_title: Optional[str] = None
    records: List[Dict[str, Any]] = []

    for block in iter_block_items(doc):
        if isinstance(block, Paragraph):
            txt = block.text.strip()
            if not txt:
                continue
            # Heuristic: treat Heading styles as report titles
            if block.style and "Heading" in block.style.name:
                # keep the full title line (often 'XXX数智化调研报告')
                current_title = txt
            continue

        if isinstance(block, Table):
            matrix = table_to_matrix(block)
            parsed = parse_tech_level_table(matrix)
            if parsed is None:
                continue
            rec: Dict[str, Any] = {"report_title": current_title or "UNKNOWN"}
            # map Chinese dims to normalized names
            rec["automation_star"] = parsed.get("自动化")
            rec["connectivity_star"] = parsed.get("网联化")
            rec["intelligence_star"] = parsed.get("智能化")
            records.append(rec)

    df = pd.DataFrame(records)
    # Deduplicate (some docs may contain repeated tables)
    if not df.empty:
        df = df.drop_duplicates(subset=["report_title"], keep="first").reset_index(drop=True)
    return df
