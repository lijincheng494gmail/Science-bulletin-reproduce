from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score


def _as_numeric_star(x: Any) -> Optional[float]:
    """
    Convert star ratings like '★★☆☆☆' (or similar) to numeric (count of '★').
    Returns None if cannot parse.
    """
    if x is None or (isinstance(x, float) and np.isnan(x)):
        return None
    s = str(x).strip()
    if not s:
        return None
    # count common star symbols
    if "★" in s:
        return float(s.count("★"))
    # tolerate 'star=3' or '3/5'
    for pat in ["/", "星"]:
        if pat in s:
            # extract first int
            import re
            m = re.search(r"(\d+)", s)
            if m:
                return float(int(m.group(1)))
    try:
        return float(s)
    except Exception:
        return None


def _to_numeric_series(s: pd.Series) -> pd.Series:
    """Best-effort conversion to numeric, including star strings."""
    if pd.api.types.is_numeric_dtype(s):
        return s.astype(float)
    # Try star conversion first
    converted = s.map(_as_numeric_star)
    if converted.notna().any():
        return converted.astype(float)
    return pd.to_numeric(s, errors="coerce")


def estimate_icc_oneway(x: np.ndarray, groups: np.ndarray) -> float:
    """
    One-way random effects ICC(1) estimate using ANOVA components.

    x: (n,) numeric values
    groups: (n,) group labels
    """
    mask = np.isfinite(x)
    x = x[mask]
    groups = groups[mask]
    if x.size < 3:
        return 0.0

    # Relabel groups to 0..G-1
    _, g = np.unique(groups, return_inverse=True)
    G = int(g.max()) + 1
    if G <= 1:
        return 0.0

    # group sizes and means
    n_g = np.bincount(g)
    means = np.array([x[g == j].mean() for j in range(G)])
    overall = x.mean()

    # SSB, SSW
    ssb = np.sum(n_g * (means - overall) ** 2)
    ssw = np.sum((x - means[g]) ** 2)

    dfb = G - 1
    dfw = x.size - G
    if dfw <= 0:
        return 0.0

    msb = ssb / dfb if dfb > 0 else 0.0
    msw = ssw / dfw

    m_bar = x.size / G
    denom = msb + (m_bar - 1.0) * msw
    if denom <= 1e-12:
        return 0.0
    icc = (msb - msw) / denom
    # Clamp (negative ICC is possible due to sampling noise)
    return float(np.clip(icc, 0.0, 0.99))


def design_effect(groups: np.ndarray, icc: float) -> float:
    """
    Kish-like design effect for unequal cluster sizes:
      deff = 1 + ICC * ( (sum n_g^2)/n - 1 )

    where n_g are cluster sizes.
    """
    if icc <= 0:
        return 1.0
    _, g = np.unique(groups, return_inverse=True)
    n_g = np.bincount(g).astype(float)
    n = float(n_g.sum())
    if n <= 1:
        return 1.0
    return float(1.0 + icc * (np.sum(n_g ** 2) / n - 1.0))


def effective_sample_size(groups: np.ndarray, icc: float) -> float:
    """n_eff = n / deff."""
    _, g = np.unique(groups, return_inverse=True)
    n = float(g.size)
    deff = design_effect(groups, icc)
    return float(max(1.0, n / deff))


@dataclass(frozen=True)
class MeasurementMetadata:
    """
    Metadata describing the dataset layout.

    group_col:
        Column name for cluster/group labels (e.g., 专业化公司 / board_id).
        If None, data is treated as i.i.d.
    id_col:
        Optional unique ID column.
    time_col:
        Optional time column (string or datetime).
    """
    group_col: Optional[str] = None
    id_col: Optional[str] = None
    time_col: Optional[str] = None


@dataclass
class ModelHints:
    """
    Heuristic hints for the Modeling layer, derived from the manifest.
    """
    suggest_hierarchical: bool
    suggest_low_rank: bool
    suggest_latent_types: bool
    notes: List[str]


@dataclass
class MeasurementManifest:
    """
    Auditable measurement manifest produced from a raw table.

    This is the 'contract' between Measurement and later layers.
    """
    n_rows: int
    n_groups: int
    group_col: Optional[str]
    group_sizes: Dict[str, int]

    missing_rate: Dict[str, float]
    icc: Dict[str, float]
    snr: Dict[str, float]
    n_eff: Dict[str, float]
    overall_n_eff: float

    corr_mean_abs: float
    corr_max_abs: float

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class MeasurementEngine:
    """
    Measurement layer: clean + quantify + generate an auditable manifest.

    Typical usage:
        engine = MeasurementEngine()
        cleaned_df, manifest, hints = engine.run(df, metadata, feature_cols=[...])
    """

    def __init__(
        self,
        icc_feature_min_obs: int = 8,
        icc_clip: Tuple[float, float] = (0.0, 0.99),
        corr_sample_cap: int = 2000,
        random_state: int = 0,
    ) -> None:
        self.icc_feature_min_obs = icc_feature_min_obs
        self.icc_clip = icc_clip
        self.corr_sample_cap = corr_sample_cap
        self.random_state = random_state

    def run(
        self,
        raw_df: pd.DataFrame,
        metadata: MeasurementMetadata,
        feature_cols: Optional[Sequence[str]] = None,
        coerce_star_to_numeric: bool = True,
    ) -> Tuple[pd.DataFrame, MeasurementManifest, ModelHints]:
        """
        Parameters
        ----------
        raw_df:
            Input dataframe (one row per factory/site).
        metadata:
            Describes group/id/time columns.
        feature_cols:
            Which columns to treat as measurable numeric features. If None,
            all columns except metadata cols are used.
        coerce_star_to_numeric:
            If True, convert '★★★☆☆' style ratings into numeric counts.

        Returns
        -------
        cleaned_df:
            A cleaned copy of raw_df (numeric coercions applied).
        manifest:
            MeasurementManifest with missingness/ICC/n_eff and correlations.
        hints:
            ModelHints for later modeling choices.
        """
        df = raw_df.copy()

        # Determine features
        reserved = set([c for c in [metadata.group_col, metadata.id_col, metadata.time_col] if c])
        if feature_cols is None:
            feature_cols = [c for c in df.columns if c not in reserved]
        feature_cols = [c for c in feature_cols if c in df.columns]

        # Coerce stars / numeric
        numeric_cols: List[str] = []
        for c in feature_cols:
            if coerce_star_to_numeric:
                df[c] = _to_numeric_series(df[c])
            else:
                df[c] = pd.to_numeric(df[c], errors="coerce")
            if pd.api.types.is_numeric_dtype(df[c]):
                numeric_cols.append(c)

        # Missingness
        missing_rate = {c: float(df[c].isna().mean()) for c in numeric_cols}

        # Group info
        group_col = metadata.group_col if (metadata.group_col in df.columns if metadata.group_col else False) else None
        if group_col is None:
            groups = np.array(["__all__"] * len(df))
        else:
            groups = df[group_col].astype(str).to_numpy()

        uniq_groups, counts = np.unique(groups, return_counts=True)
        group_sizes = {str(g): int(n) for g, n in zip(uniq_groups, counts)}
        n_groups = int(len(uniq_groups))

        # ICC, SNR, n_eff per feature
        icc: Dict[str, float] = {}
        snr: Dict[str, float] = {}
        n_eff: Dict[str, float] = {}

        for c in numeric_cols:
            x = df[c].to_numpy(dtype=float)
            if np.isfinite(x).sum() < self.icc_feature_min_obs or n_groups <= 1:
                icc[c] = 0.0
                snr[c] = 0.0
                n_eff[c] = float(np.isfinite(x).sum())
                continue

            icc_c = estimate_icc_oneway(x, groups)
            icc_c = float(np.clip(icc_c, self.icc_clip[0], self.icc_clip[1]))
            icc[c] = icc_c

            # SNR proxy: var_between / var_within
            # Use group means
            mask = np.isfinite(x)
            x2 = x[mask]
            g2 = groups[mask]
            _, gi = np.unique(g2, return_inverse=True)
            means = np.array([x2[gi == j].mean() for j in range(int(gi.max()) + 1)])
            within = np.mean([(x2[gi == j] - means[j]).var(ddof=1) if (gi == j).sum() > 1 else 0.0
                              for j in range(int(gi.max()) + 1)])
            between = means.var(ddof=1) if means.size > 1 else 0.0
            snr[c] = float(between / (within + 1e-12))

            n_eff[c] = effective_sample_size(g2, icc_c)

        overall_n_eff = float(np.median(list(n_eff.values())) if n_eff else len(df))
        overall_n_eff = float(max(2.0, overall_n_eff))

        # Correlation diagnostics (sample to cap for speed)
        corr_mean_abs = 0.0
        corr_max_abs = 0.0
        if len(numeric_cols) >= 2:
            sub = df[numeric_cols]
            if len(sub) > self.corr_sample_cap:
                sub = sub.sample(self.corr_sample_cap, random_state=self.random_state)
            corr = sub.corr(numeric_only=True).to_numpy()
            # upper triangular without diagonal
            iu = np.triu_indices_from(corr, k=1)
            vals = np.abs(corr[iu])
            vals = vals[np.isfinite(vals)]
            if vals.size:
                corr_mean_abs = float(vals.mean())
                corr_max_abs = float(vals.max())

        manifest = MeasurementManifest(
            n_rows=int(len(df)),
            n_groups=n_groups,
            group_col=group_col,
            group_sizes=group_sizes,
            missing_rate=missing_rate,
            icc=icc,
            snr=snr,
            n_eff=n_eff,
            overall_n_eff=overall_n_eff,
            corr_mean_abs=corr_mean_abs,
            corr_max_abs=corr_max_abs,
        )

        hints = self._make_hints(df, numeric_cols, manifest)
        return df, manifest, hints

    def _make_hints(
        self,
        df: pd.DataFrame,
        numeric_cols: Sequence[str],
        manifest: MeasurementManifest,
    ) -> ModelHints:
        notes: List[str] = []

        # Hierarchical hint based on ICC
        icc_vals = np.array(list(manifest.icc.values()), dtype=float) if manifest.icc else np.array([0.0])
        icc_med = float(np.median(icc_vals)) if icc_vals.size else 0.0
        suggest_hierarchical = icc_med >= 0.10 and manifest.n_groups > 1
        if suggest_hierarchical:
            notes.append(f"Median ICC≈{icc_med:.2f} → 建议优先考虑层级/分组结构模型（随机效应或组效应）。")
        else:
            notes.append(f"Median ICC≈{icc_med:.2f} → 分组相关性不强/样本不足，i.i.d. 模型可能足够。")

        # Low-rank hint based on correlations
        suggest_low_rank = manifest.corr_mean_abs >= 0.35 or manifest.corr_max_abs >= 0.80
        if suggest_low_rank:
            notes.append(
                f"特征相关性较强（mean|ρ|≈{manifest.corr_mean_abs:.2f}, max|ρ|≈{manifest.corr_max_abs:.2f}）"
                " → 可考虑低秩/因子/图结构。"
            )

        # Latent types hint via quick clustering
        suggest_latent_types = False
        if len(numeric_cols) >= 4 and len(df) >= 30:
            try:
                sub = df[list(numeric_cols)].dropna()
                if len(sub) >= 30:
                    X = sub.to_numpy(dtype=float)
                    k = min(6, max(2, int(np.sqrt(len(sub) / 2))))
                    km = KMeans(n_clusters=k, n_init="auto", random_state=self.random_state)
                    labels = km.fit_predict(X)
                    sil = silhouette_score(X, labels) if len(np.unique(labels)) > 1 else 0.0
                    if sil >= 0.20:
                        suggest_latent_types = True
                        notes.append(f"KMeans silhouette≈{sil:.2f} → 可能存在 latent factory types（可考虑混合模型/latent class）。")
            except Exception:
                # Robust: do nothing if clustering fails
                pass

        if not suggest_latent_types:
            notes.append("未检测到明显的 latent types 信号（或样本不足），可以先用显式分组/连续潜变量近似。")

        return ModelHints(
            suggest_hierarchical=bool(suggest_hierarchical),
            suggest_low_rank=bool(suggest_low_rank),
            suggest_latent_types=bool(suggest_latent_types),
            notes=notes,
        )
