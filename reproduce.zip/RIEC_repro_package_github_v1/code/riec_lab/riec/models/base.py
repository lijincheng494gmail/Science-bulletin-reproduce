from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Optional, Protocol

import numpy as np


def gaussian_loglik_from_rss(rss: float, n: int) -> float:
    """
    Gaussian log-likelihood (including constants) under plug-in σ^2 = RSS/n.

    ll = -n/2 * [log(2πσ^2) + 1]
    """
    n = int(max(1, n))
    rss = float(max(1e-12, rss))
    sigma2 = rss / n
    return float(-0.5 * n * (np.log(2.0 * np.pi * sigma2) + 1.0))


def gaussian_bic_from_rss(rss: float, n_eff: float, k: int) -> float:
    """
    BIC for Gaussian regression using effective sample size n_eff:

      BIC = -2 loglik + k log(n_eff)

    We compute loglik from rss with σ^2 = rss/n (plug-in MLE).
    """
    n_eff = float(max(2.0, n_eff))
    n = int(max(1, round(n_eff)))
    ll = gaussian_loglik_from_rss(rss=rss, n=n)
    return float(-2.0 * ll + float(k) * np.log(n_eff))


class CandidateRegressor(Protocol):
    """
    Protocol for candidate regression models used in RIEC selection.

    NOTE: models can optionally use `groups` (e.g., group fixed effects).
    """
    name: str

    def fit(self, X: np.ndarray, y: np.ndarray, groups: Optional[np.ndarray] = None) -> "CandidateRegressor":
        ...

    def predict(self, X: np.ndarray, groups: Optional[np.ndarray] = None) -> np.ndarray:
        ...

    def complexity(self, n_features: int, n_groups: int = 1) -> int:
        """
        Return model complexity k used in information criteria.
        For parametric models this is typically the number of parameters.
        """
        ...

    def clone(self) -> "CandidateRegressor":
        """
        Return a fresh, unfitted copy.
        """
        ...


@dataclass
class ModelScore:
    family: str
    model: str

    k: int
    n_eff: float

    # predictive scores
    cv_mse: float
    baseline_cv_mse: float
    xpe: float  # predictive improvement factor (baseline / model)

    # likelihood / IC scores
    rss_full: float
    loglik_full: float
    bic: float

    # RIEC combined score
    lambda_weight: float
    c_lambda: float

    # diagnostics
    r2_full: float
    passed_gatekeeper: bool

    extra: Dict[str, Any]
