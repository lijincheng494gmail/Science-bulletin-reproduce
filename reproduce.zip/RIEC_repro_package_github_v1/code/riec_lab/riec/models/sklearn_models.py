from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Optional

import numpy as np
from sklearn.base import BaseEstimator, clone
from sklearn.linear_model import LinearRegression, Ridge, Lasso
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor

from .base import CandidateRegressor


def _safe_int(x: Any, default: int = 1) -> int:
    try:
        return int(x)
    except Exception:
        return default


@dataclass
class SklearnRegressorWrapper(CandidateRegressor):
    """
    Wrap a sklearn regressor into the CandidateRegressor protocol.
    """
    estimator: BaseEstimator
    name: str
    complexity_fn: Callable[[int, int, BaseEstimator], int]

    def fit(self, X: np.ndarray, y: np.ndarray, groups: Optional[np.ndarray] = None) -> "SklearnRegressorWrapper":
        self.estimator.fit(X, y)
        return self

    def predict(self, X: np.ndarray, groups: Optional[np.ndarray] = None) -> np.ndarray:
        yhat = self.estimator.predict(X)
        return np.asarray(yhat, dtype=float)

    def complexity(self, n_features: int, n_groups: int = 1) -> int:
        return int(self.complexity_fn(n_features, n_groups, self.estimator))

    def clone(self) -> "SklearnRegressorWrapper":
        return SklearnRegressorWrapper(estimator=clone(self.estimator), name=self.name, complexity_fn=self.complexity_fn)


@dataclass
class GroupFixedEffectsWrapper(CandidateRegressor):
    """
    Add group fixed effects by appending one-hot group indicators to X.

    - During fit, we store the list of group levels seen in the training fold.
    - During predict, unseen groups get an all-zero FE vector (equivalent to baseline group).
    """
    base: CandidateRegressor
    group_levels_: Optional[np.ndarray] = None  # stored levels, dtype=str

    @property
    def name(self) -> str:
        return f"GroupFE+{self.base.name}"

    def _augment(self, X: np.ndarray, groups: Optional[np.ndarray]) -> np.ndarray:
        if groups is None:
            return X
        g = np.asarray(groups).astype(str)
        if self.group_levels_ is None:
            # if not fitted, fall back to levels in input
            levels = np.unique(g)
        else:
            levels = self.group_levels_
        # build one-hot for all but first level (baseline)
        if levels.size <= 1:
            return X
        baseline = levels[0]
        other = levels[1:]
        # one-hot columns
        fe = (g[:, None] == other[None, :]).astype(float)
        return np.hstack([X, fe])

    def fit(self, X: np.ndarray, y: np.ndarray, groups: Optional[np.ndarray] = None) -> "GroupFixedEffectsWrapper":
        if groups is not None:
            self.group_levels_ = np.unique(np.asarray(groups).astype(str))
        X2 = self._augment(X, groups)
        self.base.fit(X2, y, groups=None)
        return self

    def predict(self, X: np.ndarray, groups: Optional[np.ndarray] = None) -> np.ndarray:
        X2 = self._augment(X, groups)
        return self.base.predict(X2, groups=None)

    def complexity(self, n_features: int, n_groups: int = 1) -> int:
        # add (n_groups - 1) dummy columns
        return int(self.base.complexity(n_features=n_features + max(0, n_groups - 1), n_groups=n_groups))

    def clone(self) -> "GroupFixedEffectsWrapper":
        return GroupFixedEffectsWrapper(base=self.base.clone())


def linear_model(name: str = "Linear") -> SklearnRegressorWrapper:
    est = LinearRegression()
    def k(n_features: int, n_groups: int, est: BaseEstimator) -> int:
        return int(n_features + 1)  # intercept + coeffs
    return SklearnRegressorWrapper(estimator=est, name=name, complexity_fn=k)


def ridge(alpha: float = 1.0, name: Optional[str] = None) -> SklearnRegressorWrapper:
    est = Ridge(alpha=alpha, random_state=0)
    if name is None:
        name = f"Ridge(alpha={alpha})"
    def k(n_features: int, n_groups: int, est: BaseEstimator) -> int:
        return int(n_features + 1)
    return SklearnRegressorWrapper(estimator=est, name=name, complexity_fn=k)


def lasso(alpha: float = 0.05, name: Optional[str] = None, max_iter: int = 5000) -> SklearnRegressorWrapper:
    est = Lasso(alpha=alpha, max_iter=max_iter, random_state=0)
    if name is None:
        name = f"Lasso(alpha={alpha})"
    def k(n_features: int, n_groups: int, est: BaseEstimator) -> int:
        # upper bound
        return int(n_features + 1)
    return SklearnRegressorWrapper(estimator=est, name=name, complexity_fn=k)


def random_forest(
    n_estimators: int = 300,
    max_depth: Optional[int] = None,
    min_samples_leaf: int = 2,
    name: Optional[str] = None,
) -> SklearnRegressorWrapper:
    est = RandomForestRegressor(
        n_estimators=n_estimators,
        max_depth=max_depth,
        min_samples_leaf=min_samples_leaf,
        random_state=0,
        n_jobs=-1,
    )
    if name is None:
        name = f"RF(n={n_estimators},depth={max_depth})"

    def k(n_features: int, n_groups: int, est: BaseEstimator) -> int:
        # nonparametric: heuristic complexity proxy
        return int(n_features + 1 + max(1, int(np.log(_safe_int(getattr(est, "n_estimators", 1))))))
    return SklearnRegressorWrapper(estimator=est, name=name, complexity_fn=k)


def gbdt(
    n_estimators: int = 400,
    learning_rate: float = 0.05,
    max_depth: int = 3,
    name: Optional[str] = None,
) -> SklearnRegressorWrapper:
    est = GradientBoostingRegressor(
        n_estimators=n_estimators,
        learning_rate=learning_rate,
        max_depth=max_depth,
        random_state=0,
    )
    if name is None:
        name = f"GBDT(n={n_estimators},lr={learning_rate},d={max_depth})"

    def k(n_features: int, n_groups: int, est: BaseEstimator) -> int:
        return int(n_features + 1 + max(1, int(np.log(_safe_int(getattr(est, "n_estimators", 1))))))
    return SklearnRegressorWrapper(estimator=est, name=name, complexity_fn=k)
