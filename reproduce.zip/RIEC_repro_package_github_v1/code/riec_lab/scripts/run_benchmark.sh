#!/usr/bin/env bash
set -euo pipefail

# Main synthetic benchmark (virtual factory world).
# Usage:
#   bash scripts/run_benchmark.sh

source .venv/bin/activate

python -m riec.experiments.run_benchmark \
  --out "experiments/results/benchmark.csv"

python experiments/figures/plot_benchmark.py \
  --in "experiments/results/benchmark.csv" \
  --out "experiments/figures/benchmark_summary.png" \
  --metric "cv_risk"

echo "[run_benchmark] outputs:"
echo "  - experiments/results/benchmark.csv"
echo "  - experiments/figures/benchmark_summary.png"
