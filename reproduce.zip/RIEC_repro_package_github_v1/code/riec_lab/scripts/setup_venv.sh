#!/usr/bin/env bash
set -euo pipefail

# Create and activate a local virtualenv under .venv, then install requirements.
# Usage:
#   bash scripts/setup_venv.sh
#
# After running, you can:
#   source .venv/bin/activate

PY=${PYTHON:-python3}

if [ ! -d ".venv" ]; then
  $PY -m venv .venv
fi

source .venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt

echo "[setup_venv] done. Now run: source .venv/bin/activate"
