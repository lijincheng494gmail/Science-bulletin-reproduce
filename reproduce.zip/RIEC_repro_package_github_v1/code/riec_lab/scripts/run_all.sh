#!/usr/bin/env bash
set -euo pipefail

# End-to-end demo: set up env -> run sanity -> run benchmark -> generate plots.
# Usage:
#   bash scripts/run_all.sh

bash scripts/setup_venv.sh
bash scripts/run_sanity.sh
bash scripts/run_benchmark.sh

echo "[run_all] done."
