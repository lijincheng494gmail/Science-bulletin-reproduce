import unittest
import numpy as np
import pandas as pd

from riec.world.dgp import WorldConfig, OutcomeSpec, CofcoWorldGenerator
from riec.measurement import MeasurementEngine, MeasurementMetadata
from riec.models.sklearn_models import linear_model, ridge
from riec.selection import RIECSelector, SelectionConfig


class SmokeTests(unittest.TestCase):
    def _make_synthetic_manifest(self, n_groups: int = 5, per_group: int = 20, d: int = 8, seed: int = 0) -> pd.DataFrame:
        rng = np.random.default_rng(seed)
        rows = []
        for g in range(n_groups):
            g_shift = rng.normal(0, 0.8, size=d)
            for _ in range(per_group):
                x = g_shift + rng.normal(0, 1.0, size=d)
                row = {"group": f"G{g:02d}"}
                row.update({f"x{i+1}": x[i] for i in range(d)})
                rows.append(row)
        return pd.DataFrame(rows)

    def test_world_generator_shapes(self):
        manifest_df = self._make_synthetic_manifest(n_groups=6, per_group=15, d=8, seed=123)
        feature_cols = [c for c in manifest_df.columns if c.startswith("x")]

        gen = CofcoWorldGenerator()
        calib = gen.fit(
            manifest_df=manifest_df,
            group_col="group",
            feature_cols=feature_cols,
            n_latent_types=3,
            seed=123,
        )

        cfg = WorldConfig(n_groups=6, n_samples=80, icc_target=0.4, n_latent_types=3, seed=123)

        rng = np.random.default_rng(123)
        p = len(feature_cols)
        outcome = OutcomeSpec(
            beta=rng.normal(0, 1, size=p),
            gamma=rng.normal(0, 1, size=p),
            noise_std=1.0,
            misspec_level=0.0,
        )

        df, truth = gen.sample(cfg, calib, outcome_spec=outcome)

        self.assertIn("group", df.columns)
        self.assertIn("y", df.columns)
        self.assertEqual(df[feature_cols].shape[1], 8)
        self.assertGreaterEqual(len(df), 60)
        self.assertIn("outcome_spec", truth)

    def test_measurement_and_selection_runs(self):
        manifest_df = self._make_synthetic_manifest(n_groups=5, per_group=12, d=8, seed=42)
        feature_cols = [c for c in manifest_df.columns if c.startswith("x")]

        gen = CofcoWorldGenerator()
        calib = gen.fit(
            manifest_df=manifest_df,
            group_col="group",
            feature_cols=feature_cols,
            n_latent_types=2,
            seed=42,
        )
        cfg = WorldConfig(n_groups=5, n_samples=60, icc_target=0.5, n_latent_types=2, seed=42)

        rng = np.random.default_rng(42)
        p = len(feature_cols)
        outcome = OutcomeSpec(
            beta=rng.normal(0, 1, size=p),
            gamma=rng.normal(0, 1, size=p),
            noise_std=1.0,
            misspec_level=0.0,
        )

        df, _ = gen.sample(cfg, calib, outcome_spec=outcome)

        meta = MeasurementMetadata(group_col="group", id_col=None, time_col=None)
        eng = MeasurementEngine()
        cleaned, manifest, hints = eng.run(df, meta, feature_cols=feature_cols + ["y"])

        self.assertGreaterEqual(manifest.overall_n_eff, 2.0)
        self.assertIsInstance(hints.notes, list)

        X = cleaned[feature_cols].to_numpy()
        y = cleaned["y"].to_numpy()
        groups = cleaned["group"].to_numpy()

        model_families = {"linear": [linear_model(), ridge(alpha=1.0)]}
        selector = RIECSelector(config=SelectionConfig(cv_folds=3))
        result = selector.select(X, y, groups=groups, manifest=manifest, model_families=model_families)

        self.assertIn(result.best_family, model_families.keys())
        self.assertIn(result.best_model, [m.name for m in model_families[result.best_family]])


if __name__ == "__main__":
    unittest.main()
