"""
Quickstart example (import-style).

Run:
  python examples/quickstart.py

It will:
- Create a toy manifest
- Calibrate a world
- Sample a dataset
- Run RIEC selection
"""
import numpy as np
import pandas as pd

from riec.measurement import MeasurementMetadata
from riec.models import GroupFixedEffectsWrapper, linear_model, ridge
from riec.selection import RIECSelector, SelectionConfig
from riec.world import CofcoWorldGenerator, WorldConfig


def make_toy_manifest(seed: int = 0) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    G = 10
    rows = []
    for g in range(G):
        for i in range(25):
            rows.append(
                {
                    "board_id": f"B{g:02d}",
                    "automation_star": rng.integers(1, 5),
                    "connectivity_star": rng.integers(1, 5),
                    "intelligence_star": rng.integers(1, 5),
                    "maturity_score": rng.normal(2.0, 0.6),
                }
            )
    return pd.DataFrame(rows)


def main():
    manifest = make_toy_manifest()
    features = ["automation_star", "connectivity_star", "intelligence_star", "maturity_score"]

    gen = CofcoWorldGenerator()
    cal = gen.fit(manifest, group_col="board_id", feature_cols=features, n_latent_types=3, seed=0)
    df, truth = gen.sample(WorldConfig(n_groups=10, n_samples=250, icc_target=0.3, seed=1), cal)

    model_families = {
        "Pooled": [linear_model(), ridge(alpha=1.0)],
        "GroupFE": [GroupFixedEffectsWrapper(linear_model()), GroupFixedEffectsWrapper(ridge(alpha=1.0))],
    }

    selector = RIECSelector(config=SelectionConfig(cv_folds=5, random_state=0, c_for_lambda=1.0))
    meta = MeasurementMetadata(group_col="board_id")
    res = selector.select_from_dataframe(df, feature_cols=features, target_col="y", metadata=meta, model_families=model_families)

    print(res.as_dataframe().head(10)[["family","model","c_lambda","bic","xpe","cv_mse"]])
    print("Best:", res.best_family, res.best_model)


if __name__ == "__main__":
    main()
