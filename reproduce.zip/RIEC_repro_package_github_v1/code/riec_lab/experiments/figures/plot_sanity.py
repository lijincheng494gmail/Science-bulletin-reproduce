#!/usr/bin/env python3
"""
A tiny helper to turn the JSON emitted by run_sanity (if you redirect output)
into a quick bar plot.

This is optional; the main paper plots should be produced from benchmark runs.

Usage example:
  python -m riec.experiments.run_sanity ... > experiments/results/sanity.txt
  python experiments/figures/plot_sanity.py --in experiments/results/sanity.txt --out experiments/figures/sanity.png
"""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd


def _extract_json_from_text(text: str) -> dict:
    # Heuristic: find the last JSON-like block in the text.
    # run_sanity prints several dicts; we grab the last {...}.
    m = list(re.finditer(r"\{[\s\S]*\}", text))
    if not m:
        raise ValueError("No JSON-like block found in input file.")
    s = m[-1].group(0)
    return json.loads(s.replace("'", '"'))  # best-effort


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="inp", required=True)
    ap.add_argument("--out", dest="out", required=True)
    args = ap.parse_args()

    inp = Path(args.inp)
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)

    text = inp.read_text(encoding="utf-8", errors="ignore")
    data = _extract_json_from_text(text)

    # Expect structure: {"selected": {...}, "scores": {...}}
    scores = data.get("scores", {})
    if not scores:
        raise SystemExit("Could not find `scores` in parsed sanity output.")

    # Convert nested dict -> DataFrame
    rows = []
    for name, sd in scores.items():
        rows.append({"candidate": name, **sd})
    df = pd.DataFrame(rows).sort_values("criterion", ascending=True)

    plt.figure(figsize=(max(6, 0.6 * len(df)), 4.0))
    plt.bar(df["candidate"], df["criterion"])
    plt.xticks(rotation=45, ha="right")
    plt.ylabel("criterion (lower is better)")
    plt.title("Sanity run: criterion by candidate")
    plt.tight_layout()
    plt.savefig(out)
    print(f"[plot_sanity] wrote {out}")


if __name__ == "__main__":
    main()
