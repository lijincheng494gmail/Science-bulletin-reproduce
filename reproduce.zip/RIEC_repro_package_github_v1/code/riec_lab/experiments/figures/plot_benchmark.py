#!/usr/bin/env python3
"""plot_benchmark.py

Plot a quick summary figure from the benchmark CSV produced by:
    python -m riec.experiments.run_benchmark --out <...>/benchmark.csv

The benchmark CSV schema in this repo is:
    regime_n, regime_icc, rule, selected_family, selected_model,
    test_mse, manifest_n_eff, lambda_weight

So this plotting script focuses on columns that actually exist (default: test_mse).

Usage:
    python experiments/figures/plot_benchmark.py \
        --in 05_results/benchmark/benchmark.csv \
        --out 05_results/figures/benchmark_test_mse.png \
        --metric test_mse

Notes:
- This is intentionally dependency-light: pandas + matplotlib only.
- Metric can be any numeric column present in the CSV.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd
import matplotlib.pyplot as plt


def _make_regime_label(row: pd.Series) -> str:
    # Nice compact label for x-axis
    try:
        n = int(row["regime_n"])
    except Exception:
        n = row.get("regime_n", "?")
    icc = row.get("regime_icc", "?")
    return f"N={n}, ICC={icc}"


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="inp", required=True, help="Path to benchmark.csv")
    ap.add_argument("--out", dest="out", required=True, help="Output image path (png/pdf)")
    ap.add_argument(
        "--metric",
        default="test_mse",
        help="Which numeric column to plot (default: test_mse).",
    )
    args = ap.parse_args()

    inp = Path(args.inp)
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)

    df = pd.read_csv(inp)
    if df.empty:
        raise SystemExit(f"Empty benchmark file: {inp}")

    metric = args.metric
    if metric not in df.columns:
        raise SystemExit(
            f"Metric '{metric}' not found. Available columns: {list(df.columns)}"
        )

    # Normalize schema for plotting
    if "rule" not in df.columns:
        raise SystemExit("Missing required column: 'rule' (selection rule / method)")
    if "regime_n" not in df.columns or "regime_icc" not in df.columns:
        raise SystemExit("Missing required columns: 'regime_n' and/or 'regime_icc'")

    df = df.copy()
    df["regime"] = df.apply(_make_regime_label, axis=1)
    df["method"] = df["rule"].astype(str)

    # Aggregate: mean metric by (regime, method)
    agg = df.groupby(["regime", "method"], as_index=False)[metric].mean()

    # Build composite x labels
    agg["x"] = agg["regime"].astype(str) + " | " + agg["method"].astype(str)

    plt.figure(figsize=(max(8, 0.6 * len(agg)), 4.8))
    plt.bar(agg["x"], agg[metric])
    plt.xticks(rotation=45, ha="right")
    plt.ylabel(metric)
    plt.title(f"Benchmark summary: mean {metric} by regime × method")
    plt.tight_layout()
    plt.savefig(out)
    print(f"[plot_benchmark] wrote {out}")


if __name__ == "__main__":
    main()
