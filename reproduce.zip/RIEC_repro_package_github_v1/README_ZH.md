# RIEC / Guarded-RIEC（RIEC-B）复现包

这个仓库用于复现论文中的主要实验与图表：

**Jincheng Li, Xifeng Li, Zhe Hao**  
*Auditable Plant-Level Digitalization Diagnosis under Clustered Observations: Measurement Audit, Virtual-Factory Benchmarking, and Guarded RIEC*  
（投稿至 *Science Bulletin*，2026）

核心关注点：**可审计（auditability）** 与 **尾部风险（tail risk）**，尤其是在**分组/聚类（clustered）工业数据**场景下的模型选择稳定性。

---

## 可以复现什么？

运行仓库中的脚本可以重新生成：

1. **测量审计（Measurement audit）**  
   - 缺失率（missingness）  
   - 组内相关系数 ICC  
   - 有效样本量 \(n_{eff}\)

2. **虚拟工厂世界基准测试（Virtual-factory benchmark）**  
   - 在不同 \((N, ICC)\) regime 下对比 CV / BIC\(_{eff}\) / RIEC / RIEC-B  
   - 输出均值/中位数，以及 q90/q95/q99 等尾部指标  
   - win-rate 对比

3. **可选的 SIRI16 锚点示例**  
   - 把定量结果映射到标准术语，方便面向业务决策沟通  
   - `data/siri/` 内是本地导出的 HTML 文件（不依赖联网）

---

## 数据说明

- **仓库包含**：脱敏后的 survey manifest（`data/manifest.xlsx`）以及跑通流程所需的最小辅助文件。  
- **仓库不包含**：任何内部叙述性报告、敏感经营信息等。  
  复现包的目标是：没有内部文档也能完整复现方法、实验设计和主要图表。

---

## 快速开始

### 1）先跑一个 smoke test（确认环境）

```bash
bash RUN_SMOKE.sh
```

### 2）跑完整复现

```bash
bash RUN_ALL.sh
```

输出会写到：

- `results/sanity_audit/`  
- `results/benchmark/`  
- `results/siri_anchor/`  

如果只想快速比对，可以看 `assets/expected_outputs/` 里的示例输出。

---

## 联系方式

如需帮助：smyjl12@nottingham.edu.cn
