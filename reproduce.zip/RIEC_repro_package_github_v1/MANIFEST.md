# Manifest (files and purpose)

This repository is structured so that a reviewer can run everything from the repo root.

## Top-level scripts

- `RUN_SMOKE.sh`  
  Fast sanity check: installs/activates environment and runs a lightweight audit.

- `RUN_ALL.sh`  
  End-to-end reproduction: audit → benchmark → (optional) SIRI anchor.

## Key inputs

- `data/manifest.xlsx`  
  De-identified plant-level survey manifest used to demonstrate the audit and benchmarking pipeline.

- `data/entities_clusters.xlsx`  
  Minimal mapping / clustering metadata used by the experiments.

- `data/siri/`  
  A local SIRI16 HTML export used by the optional SIRI anchor demo.

## Code

- `code/riec_lab/`  
  The core Python package and experiment scripts.

## Outputs (generated)

All generated files are written under `results/`. You can delete `results/` anytime to rerun from scratch.

## Example outputs (for comparison)

- `assets/expected_outputs/`  
  Example plots and CSVs for a quick “does my run look reasonable?” check.

