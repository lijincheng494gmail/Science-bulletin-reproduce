# Optional SIRI16 anchor input (public version)

The original submission used a SIRI HTML export as an optional demonstration input.
This file may contain organization-specific context and is not included in the public version.

To run the SIRI16 demo:
- provide your own SIRI HTML export, and
- set `SIRI_HTML=/path/to/your_siri_export.html` when running `RUN_ALL.sh` (or run the SIRI script directly).

If you only want to reproduce the benchmark figures (tail risk, boxplots, etc.), SIRI input is not required.
