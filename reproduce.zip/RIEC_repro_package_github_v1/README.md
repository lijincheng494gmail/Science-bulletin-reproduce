# RIEC / Guarded-RIEC (RIEC-B) — Reproducibility Package

If you’re here to **rerun the experiments** or **recreate the figures/tables**, start with:

```bash
bash RUN_SMOKE.sh   # quick check
bash RUN_ALL.sh     # full reproduction
```

This repository accompanies the manuscript:

**Jincheng Li, Xifeng Li, Zhe Hao.**  
*Auditable Plant-Level Digitalization Diagnosis under Clustered Observations: Measurement Audit, Virtual-Factory Benchmarking, and Guarded RIEC.*  
(Submitted to *Science Bulletin*, 2026)

The goal is to make the whole pipeline **auditable end-to-end**, and to surface **tail-risk failures** that average metrics can miss under **clustered (non-i.i.d.) industrial data**.

---

## What this repo reproduces

1. **Measurement audit** on a plant-level survey manifest  
   - missingness summaries  
   - intraclass correlation (ICC)  
   - effective sample size (\(n_{eff}\))

2. **Virtual-factory benchmarking** under controlled regimes \((N, ICC)\)  
   - selection rules: CV, BIC\(_{eff}\), RIEC, Guarded-RIEC (RIEC-B)  
   - mean/median + tail metrics (q90/q95/q99)  
   - win-rate comparisons

3. **Optional SIRI16 anchor demo**  
   - maps quantitative gaps to a standard vocabulary for stakeholder-facing reporting  
   - uses the local SIRI16 HTML export in `data/siri/` (no online dependency)

---

## Data note (what’s included / excluded)

- **Included:** a de-identified survey manifest (`data/manifest.xlsx`) and minimal auxiliary files needed to run the pipeline end-to-end.
- **Excluded:** any proprietary narrative reports or sensitive business content.  
  The idea is that reviewers/readers can reproduce the methodology without access to internal documents.

---

## Where outputs go

All generated artifacts are written under `results/`:

- `results/sanity_audit/` — audit tables + summaries  
- `results/benchmark/` — benchmark tables, tail metrics, figures  
- `results/siri_anchor/` — optional SIRI plots + priority list

For a quick “does my run look reasonable?” check, see `assets/expected_outputs/` for example plots/CSVs.

---

## Repo layout (at a glance)

- `code/riec_lab/` — the research code (Python package + experiment scripts)
- `data/` — minimal inputs (manifest + SIRI16 export)
- `scripts/` — plotting + post-processing helpers
- `assets/expected_outputs/` — example outputs to compare against
- `docs/` — extra notes, reader guide, and the submission reproducibility statement

---

## Citation

A `CITATION.cff` file is included for convenience.

---

## Contact

If something breaks or you have questions, email: **smyjl12@nottingham.edu.cn**
