# Part 04 — Reproducibility package (for reviewers)

This folder provides a **self-contained reproducibility bundle** for the Science Bulletin submission on
**RIEC (Robustness-Integrated Evidence and Choice)** and **Guarded-RIEC (RIEC-B)**.

It is designed to let reviewers reproduce the *numerical* benchmark evidence and regenerate the
core plots/tables **offline** (no internet access required).

---

## What this package reproduces

From the included (anonymized/minimal) inputs, the reproducibility runner can regenerate:

1. **Measurement audit / sanity run**  
   Missingness summaries, intraclass correlation (ICC), and effective sample size \(n_{\mathrm{eff}}\).

2. **Virtual-factory benchmark (multi-seed)**  
   Controlled regimes \((N,\,\mathrm{ICC})\) and selection rules:
   `cv`, `bic` (BIC\(_\mathrm{eff}\)), `riec`, and `riec_b` (Guarded-RIEC / RIEC-B).

3. **Tail-risk diagnostics**  
   Boxplots (raw + log) and tail quantiles (q90 / q95 / q99), plus an auxiliary win-rate plot.

4. **Optional SIRI16 “language anchor” demo**  
   Parse a local SIRI assessment HTML export and produce a SIRI16 profile + Top‑K priority list.

> **Data note:** the included Excel/HTML files are **minimal and anonymized** for reproducibility.
> Raw cross-factory narrative reports are *not* distributed in this submission bundle.

---

## 1) Quick start (recommended)

Open a terminal and run:

```bash
# from the submission root, enter Part 04
cd 04_reproducibility/RIEC_REPRO_SUBMISSION

# (A) Smoke test (fast): sanity + 3-seed benchmark + figures
bash RUN_SMOKE.sh

# (B) Full reproduction (default): sanity + 50-seed benchmark + figures (+ optional SIRI)
bash RUN_ALL.sh
```

To skip the optional SIRI step:

```bash
RUN_SIRI=0 bash RUN_ALL.sh
```

---

## 2) Environment / requirements

- macOS or Linux (Windows users: run under **WSL2**)
- `bash`
- `python3` available in your PATH

The runner will:
- create a local virtual environment at `RIEC_REPRO_SUBMISSION/.venv/`
- install dependencies (tries `requirements.lock.txt` first; falls back to `requirements.txt`)
- install the local `riec` package from `code/riec_lab/`

---

## 3) Where outputs are written

After running, outputs are under `04_reproducibility/RIEC_REPRO_SUBMISSION/results/`:

### Sanity audit
- `results/sanity/sanity.txt`

### Benchmark (data + tables)
- `results/benchmark/benchmark_<preset>_all_<seeds>.csv`  
  (merged multi-seed benchmark results; includes a `seed` column)
- `results/benchmark/summary_<preset>_<seeds>/benchmark_summary_stats.csv`  
  (mean/median/std/q90/q95/q99 for each regime & rule)
- `results/benchmark/summary_<preset>_<seeds>/model_choice_frequency.csv`  
  (optional: what models were selected, by regime & rule)
- `results/benchmark/summary_<preset>_<seeds>/riec_b_guard_trigger_rate.csv`  
  (optional: guard trigger rate, if `guard_triggered` is logged)

### Figures
- `results/figures/<preset>_<seeds>/benchmark_mean_test_mse.png`
- `results/figures/<preset>_<seeds>/win_rate_by_regime_rule.png` *(auxiliary)*
- `results/figures/<preset>_<seeds>/tail_boxplot_test_mse.png`
- `results/figures/<preset>_<seeds>/tail_boxplot_test_mse_log.png`
- `results/figures/<preset>_<seeds>/tail_q90_by_regime_rule.png`
- `results/figures/<preset>_<seeds>/tail_q95_by_regime_rule.png`
- `results/figures/<preset>_<seeds>/tail_q99_by_regime_rule.png`

### Optional SIRI16 anchor (if enabled and HTML is present)
- `results/siri_anchor/siri_profile.csv`
- `results/siri_anchor/siri_topk.csv`
- `results/siri_anchor/siri_profile.png`
- `results/siri_anchor/siri_impact.png`
- `results/siri_anchor/siri_anchor_summary.md`

---

## 4) Mapping outputs to the manuscript

The exact *styling* of plots may differ from the manuscript PDF (which uses SB/LaTeX layout),
but the **underlying metrics and conclusions** should match.

**Main text figures**
- **Fig. 2 (mean performance):** `benchmark_mean_test_mse.png`
- **Fig. 3 (tail catastrophe, log scale):** `tail_boxplot_test_mse_log.png`
- **Fig. 4 (tail risk summary, q99):** `tail_q99_by_regime_rule.png`  
  *(If the manuscript uses a zoom-in panel, it is derived from the same CSV/table outputs.)*

**Main text tables**
- **Table 2 (tail-aware benchmark summary):**  
  `benchmark_summary_stats.csv` (filter to the reported regimes and the `q99` column)

---

## 5) Re-running with different settings

The one-click runner supports a few environment variables:

```bash
# Example: rerun quick preset with 50 seeds (defaults)
SEEDS=50 PRESET=quick SHEET=Plants_Core bash RUN_ALL.sh

# Example: point to a different Excel manifest or sheet
EXCEL="/path/to/your_manifest.xlsx" SHEET="YourSheet" bash RUN_ALL.sh

# Example: use a different SIRI HTML export
SIRI_HTML="/path/to/siri_assessment.html" bash RUN_ALL.sh
```

Variables:
- `SEEDS` (default `50`)
- `PRESET` (default `quick`)
- `SHEET` (default `Plants_Core`)
- `EXCEL` (default `data/manifest.xlsx`)
- `RUN_SIRI` (default `1`)
- `SIRI_HTML` (default `data/siri/siri_assessment.html`)

---

## 6) Notes / troubleshooting

- If installing from `requirements.lock.txt` fails (Python/OS mismatch), the script automatically
  falls back to `requirements.txt`.
- If your system cannot render non‑Latin labels in the SIRI plots (e.g., square boxes),
  the **CSV outputs are still correct**. You can either:
  - inspect `results/siri_anchor/*.csv`, or
  - install a CJK-capable font and configure Matplotlib, or
  - skip SIRI with `RUN_SIRI=0`.

---


