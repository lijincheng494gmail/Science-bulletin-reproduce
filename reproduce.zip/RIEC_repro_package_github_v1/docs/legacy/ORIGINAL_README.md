# RIEC Reproducibility Package (Science Bulletin submission)

This package contains **code + minimal runnable data + one-click scripts** to reproduce the core experimental results reported in the manuscript:
- Measurement audit & sanity run (`sanity.txt`)
- Virtual-world benchmark (multi-seed) with selection rules: `cv`, `bic`, `riec`, `riec_b`
- Heavy-tail (“tail catastrophe”) diagnostics: boxplots and tail quantiles (q90/q95/q99)
- Optional SIRI16 “language anchor” demo: parse a SIRI HTML report and produce a Top-K improvement list

---

## 0) Quick start (one command)

On **macOS / Linux** (requires `python3` in PATH):

```bash
bash RUN_ALL.sh
```

This script will:
1) create a local virtual environment `.venv/`
2) install dependencies
3) install the local `riec` package from `code/riec_lab`
4) run sanity + 50-seed benchmark + figures
5) (optional) run SIRI anchor if `data/siri/siri_assessment.html` exists

Outputs are written under:

- `results/sanity/`
- `results/benchmark/`
- `results/figures/`
- `results/siri_anchor/` (optional)

---

## 1) Tested environment

- OS: macOS 14 (Sonoma) / Linux
- Python: 3.13 (recommended)
- Dependencies: see `requirements.txt` (minimum versions) and `requirements.lock.txt` (tested lock)

---

## 2) Data files included

- `data/manifest.xlsx`  
  A structured survey “manifest” used to compute measurement audit statistics and calibrate the virtual world.
- `data/entities_clusters.xlsx`  
  Optional: entity clustering sheet used by some legacy extraction scripts.
- `data/siri/siri_assessment.html`  
  Optional: a SIRI HTML report used for the SIRI16 anchor demo.

If you need to replace the manifest with your own data, keep the **sheet name** consistent (default: `Plants_Core`) or pass a different `SHEET=` in the run command.

---

## 3) Re-running with different settings

The one-click script supports a few environment variables:

```bash
SEEDS=50 PRESET=quick SHEET=Plants_Core bash RUN_ALL.sh
```

- `SEEDS` (default 50): number of benchmark seeds
- `PRESET` (default `quick`): benchmark preset (controls regimes and model set)
- `SHEET` (default `Plants_Core`): Excel sheet name inside `manifest.xlsx`
- `RUN_SIRI` (default 1): set `RUN_SIRI=0` to skip SIRI

---

## 4) What to check after running

You should see these files:

- `results/sanity/sanity.txt`
- `results/benchmark/benchmark_quick_all_SEEDS.csv`
- `results/figures/benchmark_mean_test_mse.png`
- `results/figures/win_rate_by_regime_rule.png`
- `results/figures/tail_boxplot_test_mse.png`
- `results/figures/tail_boxplot_test_mse_log.png`
- `results/figures/tail_q90_by_regime_rule.png`
- `results/figures/tail_q95_by_regime_rule.png`
- `results/figures/tail_q99_by_regime_rule.png`

Optional (if SIRI is enabled):

- `results/siri_anchor/siri_profile.csv`
- `results/siri_anchor/siri_topk.csv`
- `results/siri_anchor/siri_profile.png`
- `results/siri_anchor/siri_impact.png`
- `results/siri_anchor/siri_anchor_summary.md`

---

## 中文说明（简要）

本压缩包用于论文复现（**代码 + 基础数据 + 一键脚本**）。

### 一键运行
```bash
bash RUN_ALL.sh
```

运行后结果在 `results/` 目录下（sanity、benchmark、figures、可选的 SIRI anchor）。

如需跳过 SIRI：
```bash
RUN_SIRI=0 bash RUN_ALL.sh
```
