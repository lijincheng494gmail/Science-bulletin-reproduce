# Package manifest

- `RUN_ALL.sh` : one-click reproducibility runner
- `RUN_SMOKE.sh` : quick smoke run (3 seeds)
- `requirements.txt` / `requirements.lock.txt` : dependencies
- `code/riec_lab/` : Python package + experiments
- `data/manifest.xlsx` : input manifest (Excel)
- `data/siri/` : optional SIRI HTML report
- `scripts/python/merge_benchmark_seeds.py` : merge per-seed results
- `scripts/python/analyze_benchmark.py` : generate figure suite + summary tables
- `results/` : output directory (created/filled by runs)
