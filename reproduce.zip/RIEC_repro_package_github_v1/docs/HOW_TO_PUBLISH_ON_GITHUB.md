# Uploading this package to GitHub (quick guide)

## Option A — GitHub Desktop (easiest, no command line)

1. Install GitHub Desktop.
2. Unzip this package to a local folder (e.g., `riec-reproducibility/`).
3. In GitHub Desktop: **File → Add local repository**.
4. Commit the files.
5. Click **Publish repository**.

## Option B — Command line (git)

1. Create an empty repo on GitHub (e.g., `riec-reproducibility`).
2. In your terminal:

```bash
cd riec-reproducibility
git init
git add .
git commit -m "Initial reproducibility package"
git branch -M main
git remote add origin https://github.com/<YOUR_USERNAME>/<YOUR_REPO>.git
git push -u origin main
```

## Option C — Web upload (works, but can be painful for nested folders)

- GitHub web UI: **Add file → Upload files**
- You’ll need to keep folder structure; for big repos, Desktop/git is recommended.
