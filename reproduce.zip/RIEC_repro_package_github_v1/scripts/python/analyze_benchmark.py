#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Analyze merged benchmark results and generate the main figure suite.

EN:
- Input: a merged benchmark CSV (concatenated over many seeds).
- Output:
  * Mean test MSE by regime & rule (bar chart)
  * Win-rate by regime & rule (bar chart)
  * Tail boxplots (raw + log scale)
  * Tail quantile bar charts (q90/q95/q99)
  * Summary tables (CSV)

中文：
- 输入：多 seed 合并后的 benchmark CSV
- 输出：均值图、胜率图、尾部分布箱线图（含 log）、q90/q95/q99 条形图，以及汇总表

Expected columns in the CSV:
  regime_n, regime_icc, rule, selected_family, selected_model, test_mse, seed
Optional columns:
  lambda_weight, lambda_weight_used, guard_triggered, manifest_n_eff
"""

import argparse
from pathlib import Path

import pandas as pd

import matplotlib
matplotlib.use("Agg")  # headless
import matplotlib.pyplot as plt


RULE_ORDER = ["cv", "bic", "riec", "riec_b"]


def _make_regime_label(df: pd.DataFrame) -> pd.Series:
    return df.apply(lambda r: f"N={int(r.regime_n)}, ICC={r.regime_icc}", axis=1)


def plot_mean(df: pd.DataFrame, out_png: Path) -> None:
    df = df.copy()
    df["regime"] = _make_regime_label(df)
    # keep only rules present
    rules = [r for r in RULE_ORDER if r in set(df["rule"])]

    df["rule"] = pd.Categorical(df["rule"], categories=rules, ordered=True)

    agg = df.groupby(["regime", "rule"], as_index=False)["test_mse"].mean()
    pivot = agg.pivot(index="regime", columns="rule", values="test_mse")
    pivot = pivot.loc[sorted(pivot.index)]

    ax = pivot.plot(kind="bar")
    ax.set_ylabel("test_mse (lower is better)")
    ax.set_title("Benchmark: mean test MSE by regime & rule")
    plt.tight_layout()
    out_png.parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(out_png, dpi=200)
    plt.close()


def plot_win_rate(df: pd.DataFrame, out_png: Path) -> None:
    """Win rate = P(rule has smallest test_mse) for each regime (over seeds)."""
    df = df.copy()
    if "seed" not in df.columns:
        raise ValueError("Column 'seed' is required for win-rate. Please merge with seeds.")

    df["regime"] = _make_regime_label(df)
    rules = [r for r in RULE_ORDER if r in set(df["rule"])]

    # For each (seed, regime), pick rule with minimal test_mse
    grp = df.groupby(["seed", "regime"], as_index=False)
    winners = grp.apply(lambda g: g.loc[g["test_mse"].idxmin(), "rule"], include_groups=False)
    winners = winners.rename("winner").reset_index()

    win = winners.groupby(["regime", "winner"]).size().reset_index(name="wins")
    totals = winners.groupby(["regime"]).size().reset_index(name="total")
    win = win.merge(totals, on="regime", how="left")
    win["win_rate"] = win["wins"] / win["total"]

    win["winner"] = pd.Categorical(win["winner"], categories=rules, ordered=True)

    pivot = win.pivot(index="regime", columns="winner", values="win_rate").fillna(0.0)
    pivot = pivot.loc[sorted(pivot.index)]

    ax = pivot.plot(kind="bar")
    ax.set_ylabel("win rate (higher is better)")
    ax.set_title("Benchmark: win rate by regime & rule (lowest test MSE)")
    plt.tight_layout()
    out_png.parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(out_png, dpi=200)
    plt.close()


def plot_tail_boxplots(df: pd.DataFrame, out_png: Path, log_scale: bool = False) -> None:
    df = df.copy()
    df["regime"] = _make_regime_label(df)
    rules = [r for r in RULE_ORDER if r in set(df["rule"])]

    # Create 16 categories (regime x rule)
    df["cat"] = df.apply(lambda r: f"{r.regime}\n{r.rule}", axis=1)

    # stable order
    regimes_sorted = sorted(df["regime"].unique())
    cats_order = []
    for reg in regimes_sorted:
        for rule in rules:
            cats_order.append(f"{reg}\n{rule}")
    df["cat"] = pd.Categorical(df["cat"], categories=cats_order, ordered=True)

    data = [df.loc[df["cat"] == c, "test_mse"].values for c in cats_order]

    plt.figure(figsize=(max(10, len(cats_order) * 0.7), 5))
    plt.boxplot(data, labels=cats_order, showfliers=True)

    plt.xticks(rotation=45, ha="right")
    plt.ylabel("test_mse")
    title = "Tail distribution of test MSE (boxplot)"
    if log_scale:
        plt.yscale("log")
        title += " [log scale]"
    plt.title(title)
    plt.tight_layout()
    out_png.parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(out_png, dpi=200)
    plt.close()


def plot_tail_quantile(df: pd.DataFrame, q: float, out_png: Path) -> None:
    df = df.copy()
    df["regime"] = _make_regime_label(df)
    rules = [r for r in RULE_ORDER if r in set(df["rule"])]

    df["rule"] = pd.Categorical(df["rule"], categories=rules, ordered=True)

    agg = (
        df.groupby(["regime", "rule"], as_index=False)["test_mse"]
        .quantile(q)
        .rename(columns={"test_mse": f"q{int(q*100)}"})
    )
    pivot = agg.pivot(index="regime", columns="rule", values=f"q{int(q*100)}")
    pivot = pivot.loc[sorted(pivot.index)]

    ax = pivot.plot(kind="bar")
    ax.set_ylabel(f"q{int(q*100)} of test_mse (lower is better)")
    ax.set_title(f"Benchmark: tail quantile q{int(q*100)} by regime & rule")
    plt.tight_layout()
    out_png.parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(out_png, dpi=200)
    plt.close()


def write_summary_tables(df: pd.DataFrame, out_dir: Path) -> None:
    out_dir.mkdir(parents=True, exist_ok=True)

    # summary stats
    def q(p: float):
        return lambda s: s.quantile(p)

    agg = df.groupby(["regime_n", "regime_icc", "rule"], as_index=False)["test_mse"].agg(
        mean="mean",
        median="median",
        std="std",
        q90=q(0.90),
        q95=q(0.95),
        q99=q(0.99),
    )
    agg.to_csv(out_dir / "benchmark_summary_stats.csv", index=False)

    # model choice frequency
    freq = (
        df.groupby(["regime_n", "regime_icc", "rule", "selected_model"], as_index=False)
        .size()
        .rename(columns={"size": "count"})
    )
    # add fraction within (regime, rule)
    totals = freq.groupby(["regime_n", "regime_icc", "rule"], as_index=False)["count"].sum().rename(
        columns={"count": "total"}
    )
    freq = freq.merge(totals, on=["regime_n", "regime_icc", "rule"], how="left")
    freq["fraction"] = freq["count"] / freq["total"]
    freq.sort_values(["regime_n", "regime_icc", "rule", "count"], ascending=[True, True, True, False]).to_csv(
        out_dir / "model_choice_frequency.csv", index=False
    )

    # guard trigger rate (if present)
    if "guard_triggered" in df.columns:
        g = df[df["rule"] == "riec_b"].copy()
        if len(g) > 0:
            trig = (
                g.groupby(["regime_n", "regime_icc"], as_index=False)["guard_triggered"]
                .mean()
                .rename(columns={"guard_triggered": "trigger_rate"})
            )
            trig.to_csv(out_dir / "riec_b_guard_trigger_rate.csv", index=False)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="inp", required=True, help="merged benchmark CSV")
    ap.add_argument("--fig_dir", required=True, help="output directory for figures")
    ap.add_argument("--table_dir", required=True, help="output directory for summary tables")
    args = ap.parse_args()

    inp = Path(args.inp)
    fig_dir = Path(args.fig_dir)
    table_dir = Path(args.table_dir)

    df = pd.read_csv(inp)

    # Figures
    plot_mean(df, fig_dir / "benchmark_mean_test_mse.png")
    plot_win_rate(df, fig_dir / "win_rate_by_regime_rule.png")
    plot_tail_boxplots(df, fig_dir / "tail_boxplot_test_mse.png", log_scale=False)
    plot_tail_boxplots(df, fig_dir / "tail_boxplot_test_mse_log.png", log_scale=True)
    plot_tail_quantile(df, 0.90, fig_dir / "tail_q90_by_regime_rule.png")
    plot_tail_quantile(df, 0.95, fig_dir / "tail_q95_by_regime_rule.png")
    plot_tail_quantile(df, 0.99, fig_dir / "tail_q99_by_regime_rule.png")

    # Tables
    write_summary_tables(df, table_dir)


if __name__ == "__main__":
    main()
