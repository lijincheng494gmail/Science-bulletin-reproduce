#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Merge per-seed benchmark CSV files into a single CSV (adds a `seed` column).

EN:
- Input: a directory containing CSV files like `benchmark_seed7.csv`
- Output: one CSV with an extra `seed` column.

中文：
- 输入：保存了每个 seed 结果的目录
- 输出：合并后的 CSV，并自动添加 seed 列
"""

import argparse
import re
from pathlib import Path

import pandas as pd


SEED_PATTERNS = [
    re.compile(r"seed(\d+)", re.IGNORECASE),
    re.compile(r"_s(\d+)", re.IGNORECASE),
]


def parse_seed_from_name(name: str) -> int | None:
    for pat in SEED_PATTERNS:
        m = pat.search(name)
        if m:
            return int(m.group(1))
    return None


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--in_dir", required=True, help="directory containing per-seed CSV files")
    ap.add_argument("--out", required=True, help="output merged CSV")
    ap.add_argument("--glob", default="*.csv", help="glob pattern (default: *.csv)")
    args = ap.parse_args()

    in_dir = Path(args.in_dir)
    out = Path(args.out)

    files = sorted(in_dir.glob(args.glob))
    if not files:
        raise SystemExit(f"No CSV files found under: {in_dir} (glob={args.glob})")

    frames = []
    missing_seed = 0
    for f in files:
        df = pd.read_csv(f)
        seed = parse_seed_from_name(f.name)
        if seed is None:
            missing_seed += 1
            seed = -1
        df["seed"] = seed
        frames.append(df)

    out.parent.mkdir(parents=True, exist_ok=True)
    merged = pd.concat(frames, ignore_index=True)
    merged.to_csv(out, index=False)

    print("Merged:", len(files), "files ->", out)
    if missing_seed:
        print("WARN: could not parse seed for", missing_seed, "files (seed=-1).")


if __name__ == "__main__":
    main()
