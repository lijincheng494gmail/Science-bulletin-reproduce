# scripts/

This directory contains helper scripts used by `RUN_ALL.sh`.

- `python/merge_benchmark_seeds.py`: merge per-seed CSVs and add a `seed` column.
- `python/analyze_benchmark.py`: generate figure suite + summary tables.

These scripts are intentionally **plain Python** (pandas + matplotlib) to keep the
reproducibility package self-contained.
